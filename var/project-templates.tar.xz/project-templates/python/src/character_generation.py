#!/usr/bin/env python3

# ruff: noqa: S311 - pseudo random number generation is OK for this use case.

"""Character Profile Generation Module.

This module provides functionalities for generating and updating character
profiles, including psychological attributes, life events, and demographic
details. It interacts with external helper scripts and uses OpenAI's API to
embellish character details with context-specific information.

Dependencies:
    - os
    - sys
    - requests
    - re
    - copy
    - datetime
    - numpy
    - pandas
    - json
    - random
    - string
    - pathlib
    - importlib.util

Functions:
    year_category_map()
        A function to return a dictionary of age category strings to their
        numeric value.

    get_reception_sentiment(accept=None):
       This function returns a string in the form 'acceptance sentiment 2'
       or 'rejection sentiment: -3'

    get_proposal_sentiment():
        This function returns a string in the form: 'proposal sentiment 2'

    perturb_value(value, mean_change, std_dev)
        Perturbs a given value by a normally distributed random amount.

    initialize_or_update_profile(age, profile=None)
        Initializes or updates a psychological profile dictionary based on the
        age of the person.

    weighted_random_time_interval(max_time_in_years, year_category_map):
       Generate a random interval (weighted to shorter terms) given a maximum
       time in years.

    random_time_at_company
       Generate a random interval (weighted to shorter terms) at the company which will
       not be bigger than the time the company has been open or longer than the working
       life of the character.

    get_activity_components(type, MONITORING):
       Get a random number of consecutive topics from the given alert type.
       (currently only type = 'QPQ' is valid)

    get_activity_components_grouped_by_email_pair(
    type, MONITORING, get_activity_components)
       Group current alert type list into an arbetrary number of emails.
       (currently only type = 'QPQ' is valid)

    generate_topics_and_events(flat_LIFE_EVENTS, flat_TOPICS_TREE,
                               topics=[3, 6], events=[3, 6])
       Generates a dictionary of random topics and events as required.

    get_personal_bias(PERSONAL_BIAS: dict, sample_size: int = 0,
                     count: list[int] = None) -> list[list[str]]:
       This function returns a bias from PERSONAL_BIAS given a probability for
       all biases passed as a list. SAMPLE_SIZE is the number of unique
       samples to be taken from the bias'. COUNT is the number of each type of
       bias' to be assumed when sampling is carried out.

    list_to_enumerated_string(items)
        Converts a list of strings into an enumerated human-readable English
        list.

    select_relationship_of_pair
        Given a dictionary of relationships, randomly select a collection of
        relationships between two characters without contradiction.

    get_character_pair
        Given two integers A_id and B_id, this function will create a character
        pair with additional base data.

    age_string_from_tens(ten=None)
        Returns a category for a given multiple of ten. Pass 'None' to see all
        multiples.

    age_tens_from_string(ageString=None)
        Returns a multiple of ten given a category. Pass 'None' to see all
        categories.

    get_last_processed_file(PARENT_FILE)
        Returns the last processed character file information in the folder
        GENERATED_CHARACTERS under the provided PARENT_FILE.

    pick_new_agenda(AGENDAS, TOPIC_PERIOD)
        Returns a new agenda weighted appropriately for the given age
        in string TOPIC_PERIOD using the given AGENDAS dictionary which contains a key
        'ALL' for non age related agendas and keys corresponding to each TOPIC_PERIOD.

    generate_base_character(flat_NATIONALITY_TREE)
        Builds a base character profile given a distribution of nationalities
        and cultural backgrounds.

    generate_TOPIC_detail(character, inbound_params, toggles, topic_number)
        Provides a dictionary object ready to send to the OpenAI API for
        generating detailed topics.

    generate_file_paths_for_character_process
        Generate the file-paths needed in the character generation process.

    generate_character_topic_batch_file
        Given file paths and prompt parameters, generate a series of prompts
        and save to a batch file.
        If this is the first topic in a series (TOPIC_NUMBER = 0) then we must
        first generate topics and events for each character in the new
        TOPIC_PERIOD.

    enrich_character_topics
        Build a dictionary from the returned data and enrich the character
        records.

    update_character_profile
        This function updates an existing character profile adding basic
        topics and events. It also updates the character metrics randomly
        in accordance with the changes expected at the given age.

    topic_processing(home_path, topic_id, toggles, model_parameters)
        Enrich a full batch of characters using OpenAI to enrich the topics
        randomly selected for those characters. This results in production of a
        full specification for each character.
"""

import copy
import datetime
import importlib.util
import json
import logging
import os
import random
import string
import sys
from collections.abc import Callable
from datetime import date
from pathlib import Path
from typing import Union

from dotenv import load_dotenv

home_path = Path.cwd().parent

# Load environment variables from .env file
load_dotenv()

ENV = os.getenv("ENV")

# Set log file path based on environment
log_file_path = (
    "logs/app.log"
    if ENV == "development"
    else "/var/log/character_generation/app.log"
)

# Ensure the logs directory exists
Path(log_file_path).parent.mkdir(parents=True, exist_ok=True)

# # Set logging level based on the environment
log_level = logging.DEBUG if ENV == "development" else logging.WARNING

logging.basicConfig(
    filename=log_file_path,
    level=log_level,
    format="%(asctime)s - %(levelname)s - %(message)s",
)

helpers_file_path = Path(home_path).joinpath("OpenAI", "src", "helpers.py")
spec = importlib.util.spec_from_file_location("helpers", helpers_file_path)
helpers = importlib.util.module_from_spec(spec)
sys.modules["helpers"] = helpers
spec.loader.exec_module(helpers)

openai_helpers_file_path = Path(home_path).joinpath(
    "OpenAI", "src", "openai_helpers.py",
)
# load our openai_helpers library.
openai_spec = importlib.util.spec_from_file_location(
    "openai_helpers", openai_helpers_file_path,
)
openai_helpers = importlib.util.module_from_spec(openai_spec)
sys.modules["openai_helpers"] = openai_helpers
openai_spec.loader.exec_module(openai_helpers)


def year_category_map(category_string: str = "") -> int:
    """Return the number of years given an interval string.

    To return the full string map, omit the string argument.
    """
    cat_map = {
        "1 month": 1 / 12,
        "3 months": 0.25,
        "6 months": 0.5,
        "9 months": 0.75,
        "1 year": 1,
        "2 year": 2,
        "3 years": 3,
        "5 years": 5,
        "7 years": 7,
        "10 years": 10,
        "15 years": 15,
        "20 years": 20,
        "25 years": 25,
        "30 years": 30,
        "35 years": 35,
        "40 years": 40,
        "45 years": 45,
        "50 years": 50,
    }

    if category_string in cat_map:
        return cat_map[category_string]

    if category_string == "":
        return cat_map

    logging.info("category_string not recognised.")

    return None


def get_reception_sentiment(accept=None):
    """Create a sentiment value.

    This function returns a string in the form:
       'acceptance sentiment 2'
       'rejection sentiment: -3'
    The number is a randomly generated integer between 1 and 5 which is positive for 
    acceptance and negative for rejection. Passing no argument randomly selects either 
    positive or negative. Passing True forces an acceptance and passing False forces a 
    rejection. In either case a commensurate random integer is provided.
    see also: get_proposal_sentiment
    """
    if accept:
        response = "acceptance sentiment"
    elif accept is None:
        response = random.choice(["acceptance sentiment", "rejection sentiment"])
    else:
        response = "rejection sentiment"

    sentiment = (
        random.randint(1, 5)
        if response == "acceptance sentiment"
        else -1 * random.randint(1, 5)
    )

    return f"{response}: {sentiment}"


def get_proposal_sentiment():
    """
    This function returns a string in the form:
       'proposal sentiment 2'
    The number is a randomly generated positive integer
    between 1 and 5.
    """
    return f"proposal sentiment: {random.randint(1,5)}"


def perturb_value(value, mean_change, std_dev) -> float:
    """
    Perturbs a given value by a normally distributed random amount.

        Args:
        value (float): The original value to be perturbed.
        mean_change (float): The mean change expected for the age group.
        std_dev (float): The standard deviation of the change.

        Returns:
        float: The perturbed value.
    """
    change = random.normalvariate(mean_change, std_dev)
    return round(value + change, 2)


def initialize_or_update_profile(age: int, in_profile: dict = None) -> dict:
    """Initialise or update a psychological profile dictionary based on age.

    If an existing profile is provided, it adds incremental updates appropriate
    for the new age group.
    If no profile is provided, it initializes the profile with values suitable
    for the given age.
    Example usage
    ages = [10, 20, 30, 40, 50, 60]
    profiles = {age: initialize_or_update_profile(age) for age in ages}
    for age, profile in profiles.items():
        print(f"Profile for age {age}:")
        print(profile)
        print()
    # Updating an existing profile
    existing_profile = {
        "Intelligence Quotient (I.Q.)": 105,
        "Social Intelligence (S.I.)": 75,
        "Emotional Quotient (E.Q.)": 80,
        "Creativity Quotient (C.Q.)": 85,
        "Practical Intelligence (P.Q.)": 75,
        "Resilience (R.Q.)": 75,
        "Adaptability Quotient (A.Q.)": 80,
        "Grit": 70,
        "Moral Intelligence (M.I.)": 60,
        "Health Quotient (H.Q.)": 85,
        "BIG_FIVE": {
            "Openness to Experience": 7,
            "Conscientiousness": 6,
            "Extroversion": 8,
            "Agreeableness": 7,
            "Neuroticism": 6
        }
    }
    updated_profile = initialize_or_update_profile(30, existing_profile)
    print(f"Updated profile for age 30:")
    print(updated_profile)

    Args:
        age (int): The age of the person (should be a multiple of 10 between 10
                                          and 60).
        in_profile (dict, optional): An existing profile dictionary to be updated.
        Defaults to None.

    Returns:
        dict: A dictionary with the initialized or updated psychological
        profile.

    """
    profile = copy.deepcopy(in_profile)

    # Define the means and standard deviations for changes in each age bracket
    change_parameters = {
        10: {
            "I.Q.": (0, 2),
            "S.I.": (1, 2),
            "E.Q.": (1, 2),
            "C.Q.": (0, 2),
            "P.Q.": (1, 2),
            "R.Q.": (1, 2),
            "A.Q.": (1, 2),
            "Grit": (1, 2),
            "M.I.": (0, 2),
            "H.Q.": (0, 3),
            "BIG_FIVE": {
                "Openness to Experience": (0, 1),
                "Conscientiousness": (0, 1),
                "Extroversion": (0, 1),
                "Agreeableness": (0, 1),
                "Neuroticism": (0, 1),
            },
        },
        20: {
            "I.Q.": (0, 2),
            "S.I.": (1, 2),
            "E.Q.": (1, 2),
            "C.Q.": (0, 2),
            "P.Q.": (1, 2),
            "R.Q.": (1, 2),
            "A.Q.": (1, 2),
            "Grit": (1, 2),
            "M.I.": (0, 2),
            "H.Q.": (0, 3),
            "BIG_FIVE": {
                "Openness to Experience": (0, 1),
                "Conscientiousness": (1, 1),
                "Extroversion": (-0.5, 1),
                "Agreeableness": (1, 1),
                "Neuroticism": (-0.5, 1),
            },
        },
        30: {
            "I.Q.": (0, 2),
            "S.I.": (1, 2),
            "E.Q.": (1, 2),
            "C.Q.": (0, 2),
            "P.Q.": (1, 2),
            "R.Q.": (1, 2),
            "A.Q.": (1, 2),
            "Grit": (1, 2),
            "M.I.": (0, 2),
            "H.Q.": (0, 3),
            "BIG_FIVE": {
                "Openness to Experience": (0, 1),
                "Conscientiousness": (1, 1),
                "Extroversion": (-0.5, 1),
                "Agreeableness": (1, 1),
                "Neuroticism": (-0.5, 1),
            },
        },
        40: {
            "I.Q.": (0, 2),
            "S.I.": (1, 2),
            "E.Q.": (1, 2),
            "C.Q.": (0, 2),
            "P.Q.": (1, 2),
            "R.Q.": (1, 2),
            "A.Q.": (1, 2),
            "Grit": (1, 2),
            "M.I.": (0, 2),
            "H.Q.": (-1, 3),
            "BIG_FIVE": {
                "Openness to Experience": (0, 1),
                "Conscientiousness": (1, 1),
                "Extroversion": (-0.5, 1),
                "Agreeableness": (1, 1),
                "Neuroticism": (-0.5, 1),
            },
        },
        50: {
            "I.Q.": (0, 2),
            "S.I.": (1, 2),
            "E.Q.": (1, 2),
            "C.Q.": (0, 2),
            "P.Q.": (1, 2),
            "R.Q.": (1, 2),
            "A.Q.": (1, 2),
            "Grit": (1, 2),
            "M.I.": (0, 2),
            "H.Q.": (-2, 3),
            "BIG_FIVE": {
                "Openness to Experience": (0, 1),
                "Conscientiousness": (1, 1),
                "Extroversion": (-0.5, 1),
                "Agreeableness": (1, 1),
                "Neuroticism": (-0.5, 1),
            },
        },
        60: {
            "I.Q.": (0, 2),
            "S.I.": (1, 2),
            "E.Q.": (1, 2),
            "C.Q.": (0, 2),
            "P.Q.": (1, 2),
            "R.Q.": (1, 2),
            "A.Q.": (1, 2),
            "Grit": (1, 2),
            "M.I.": (0, 2),
            "H.Q.": (-3, 3),
            "BIG_FIVE": {
                "Openness to Experience": (0, 1),
                "Conscientiousness": (1, 1),
                "Extroversion": (-0.5, 1),
                "Agreeableness": (1, 1),
                "Neuroticism": (-0.5, 1),
            },
        },
    }

    # Initialize a new profile if none is provided
    if profile is None:
        profile = {
            "Intelligence Quotient (I.Q.)": 100,
            "Social Intelligence (S.I.)": 70,
            "Emotional Quotient (E.Q.)": 70,
            "Creativity Quotient (C.Q.)": 70,
            "Practical Intelligence (P.Q.)": 70,
            "Resilience (R.Q.)": 70,
            "Adaptability Quotient (A.Q.)": 70,
            "Grit": 70,
            "Moral Intelligence (M.I.)": 50,
            "Health Quotient (H.Q.)": 90,
            "BIG_FIVE": {
                "Openness to Experience": 5,
                "Conscientiousness": 5,
                "Extroversion": 5,
                "Agreeableness": 5,
                "Neuroticism": 5,
            },
        }

    # Apply incremental updates based on age group
    changes = change_parameters.get(age)
    age_multiple_error = "Age must be a multiple of 10 between 10 and 60."

    if not changes:
        raise ValueError(age_multiple_error)

    profile["Intelligence Quotient (I.Q.)"] = perturb_value(
        profile["Intelligence Quotient (I.Q.)"], *changes["I.Q."],
    )
    profile["Social Intelligence (S.I.)"] = perturb_value(
        profile["Social Intelligence (S.I.)"], *changes["S.I."],
    )
    profile["Emotional Quotient (E.Q.)"] = perturb_value(
        profile["Emotional Quotient (E.Q.)"], *changes["E.Q."],
    )
    profile["Creativity Quotient (C.Q.)"] = perturb_value(
        profile["Creativity Quotient (C.Q.)"], *changes["C.Q."],
    )
    profile["Practical Intelligence (P.Q.)"] = perturb_value(
        profile["Practical Intelligence (P.Q.)"], *changes["P.Q."],
    )
    profile["Resilience (R.Q.)"] = perturb_value(
        profile["Resilience (R.Q.)"], *changes["R.Q."],
    )
    profile["Adaptability Quotient (A.Q.)"] = perturb_value(
        profile["Adaptability Quotient (A.Q.)"], *changes["A.Q."],
    )
    profile["Grit"] = perturb_value(profile["Grit"], *changes["Grit"])
    profile["Moral Intelligence (M.I.)"] = perturb_value(
        profile["Moral Intelligence (M.I.)"], *changes["M.I."],
    )
    profile["Health Quotient (H.Q.)"] = perturb_value(
        profile["Health Quotient (H.Q.)"], *changes["H.Q."],
    )

    for trait, change_range in changes["BIG_FIVE"].items():
        profile["BIG_FIVE"][trait] = max(
            0,
            min(
                10,
                int(perturb_value(profile["BIG_FIVE"][trait], *change_range)),
            ),
        )

    return profile


def weighted_random_time_interval(max_time_in_years, year_category_map):
    """
    Generate a random interval (weighted to shorter terms) given a maximum
    time in years.
    """

    term_selection = [
        k for k, v in list(year_category_map.items()) if v <= max_time_in_years
    ]

    w = [i for i in range(5, len(term_selection))]
    w.reverse()
    w = [len(term_selection) - 1] * 5 + w
    return random.sample(term_selection, k=1, counts=w)[0]


def random_time_at_company(
    character_age,
    business_age,
    ENTITY_AGE_KEYS,
    year_category_map,
):
    """Generate a random period to be in Characters current role.

    Generate a random interval (weighted to shorter terms) at the company which will
    not be bigger than the time the company has been open or longer than the working
    life of the character.
    """
    term_selection = [
        k
        for k, v in list(year_category_map.items())
        if v < min(character_age - 15, ENTITY_AGE_KEYS[business_age])
    ]

    w = list(range(5, len(term_selection)))
    w.reverse()
    w = [len(term_selection) - 1] * 5 + w
    return random.sample(term_selection, k=1, counts=w)[0]


def get_activity_components(misconduct_type, MONITORING):
    """
    Get a random number of consecutive topics from the given alert type.
    (currently only type = 'QPQ' is valid)
    """
    l = len(MONITORING[misconduct_type].keys())
    s = random.randint(0, l - 1)
    f = random.randint(s + 1, l)
    return [list(MONITORING[misconduct_type].keys())[i] for i in range(s, f)]


def get_activity_components_grouped_by_email_pair(
        misconduct_type: str,
        MONITORING: dict,
        get_activity_components: Callable,
) -> [str]:
    """Generate activity components grouped by email chain.

    Group current alert type list into an arbetrary number of emails.
    (currently only type = 'QPQ' is valid)
    """
    behaviours = get_activity_components(misconduct_type, MONITORING)
    count_behaviours = len(behaviours)
    number_of_emails = random.randint(1, count_behaviours)
    topics_in_emails = sorted(
        list(range(number_of_emails))
        + random.choices(
            list(range(number_of_emails)),
            k=(count_behaviours - number_of_emails),
        ),
    )

    email_list = [[]] * number_of_emails

    for i, t in enumerate(topics_in_emails):
        crnt_list = email_list[t]
        if crnt_list == []:
            crnt_list = [behaviours[i]]
        else:
            crnt_list.append(behaviours[i])
        email_list[t] = crnt_list

    return email_list


def generate_topics_and_events(
    flat_LIFE_EVENTS: list[dict],
    flat_TOPICS_TREE: list[dict],
    AGENDAS_TREE: dict,
    topics: list[int] = [3, 6],
    events: list[int] = [3, 6],
    agendas: [int] = [3, 6],
    inbound_PREVIOUS_AGENDA: list[dict] = None,
    crnt_TOPIC_PERIOD: str = "CHILDHOOD",
) -> dict:
    """
    function takes the flat_LIFE_EVENTS, flat_TOPICS_TREE, AGENDAS_TREE data
    objects and two lists of 2 integers each giving the upper and lower values
    of ranges of numbers that represent the possible number of events and
    topics to be selected. The actual counts will be randomly selected from
    that range. These objects are returned in a dictionary under the 'topics'
    and 'events' keys. If the range for topics and events isn't given [3,6] is
    assumed for both (random number between 3 and 6 inclusive).

    example:
    generate_topics_and_events(
        flat_LIFE_EVENTS, flat_TOPICS_TREE, AGENDAS_TREE,
        topics=[3, 6],
        events=[3, 6],
        agendas=[3, 6],
        PREVIOUS_AGENDA)
    {'topics': [{'TOPIC_GROUP': 'Public Relations',
       'TOPIC_DETAIL': 'Press Conferences'},
      {'TOPIC_GROUP': 'Robotics', 'TOPIC_DETAIL': 'Robotic Detection Systems'},
      {'TOPIC_GROUP': 'Dance', 'TOPIC_DETAIL': 'Can-Can'},
      {'TOPIC_GROUP': 'Cooking', 'TOPIC_DETAIL': 'Picnic Cooking'},
      {'TOPIC_GROUP': 'Charity', 'TOPIC_DETAIL': 'Online Education Platforms'}]
     'events': [{'EVENT': 'Health',
       'EVENT_DETAIL': "Describes having a poor perception of one's physical
                        appearance, affecting mental health.",
                       'SENTIMENT': -6},
      {'EVENT': 'Family',
       'EVENT_DETAIL': 'Recognising and celebrating significant accomplishments
                        within the family.',
                        'SENTIMENT': 8},
                        {'EVENT': 'Personal Growth',
       'EVENT_DETAIL': 'Removing toxic friendships and fostering healthier
                        ones.',
                        'SENTIMENT': 8},
                        {'EVENT': 'Loss and Grief',
       'EVENT_DETAIL': 'Coping with losing a job.',
       'SENTIMENT': -6},
      {'EVENT': 'Culture and Spirituality',
       'EVENT_DETAIL': "Struggling with doubt about one's religious beliefs or
                         spiritual practices.",
                        'SENTIMENT': -8}]}

    """

    payload = {}

    if topics is not None:
        # randomly select a set of between 4 and 6 life topics.
        life_topics = []
        n = random.randint(topics[0], topics[1])
        for e in random.sample(flat_TOPICS_TREE, k=n):
            life_topics.append({"TOPIC_GROUP": e[0], "TOPIC_DETAIL": e[1]})

        payload["topics"] = life_topics

    if events is not None:
        # randomly select a set of between 2 and 4 life events.
        # evaluate them using between 6 and 9 of the evaluation types.
        life_events = []
        n = random.randint(events[0], events[1])
        for e in random.sample(flat_LIFE_EVENTS, k=n):
            individual_sentiment = e[2] + random.randint(-3, 3)
            # add some randomness to the impact of the event on the individual.
            if individual_sentiment > 10:
                individual_sentiment = 10
            if individual_sentiment < -10:
                individual_sentiment = -10

            life_events.append(
                {
                    "EVENT": e[0],
                    "EVENT_DETAIL": e[1],
                    "SENTIMENT": individual_sentiment,
                }
            )

        payload["events"] = life_events

    if agendas is not None:
        count_of_agendas_to_add = random.randint(agendas[0], agendas[1])

        if inbound_PREVIOUS_AGENDA is None or crnt_TOPIC_PERIOD == "CHILDHOOD":
            NEW_AGENDA = [
                pick_new_agenda(AGENDAS_TREE, "CHILDHOOD")[0]
                for i in range(random.randint(1, count_of_agendas_to_add))
            ]

        else:
            PREVIOUS_AGENDA = copy.deepcopy(inbound_PREVIOUS_AGENDA)
            count_of_agendas_to_remove = random.randint(agendas[0], agendas[1])

            count_of_agendas_to_add = max(
                count_of_agendas_to_add,
                max(0, min(0, len(PREVIOUS_AGENDA) - count_of_agendas_to_remove)),
            )
            if (
                count_of_agendas_to_add
                + len(PREVIOUS_AGENDA)
                - count_of_agendas_to_remove
            ) < 1:
                count_of_agendas_to_add = 1 + abs(
                    len(PREVIOUS_AGENDA) - count_of_agendas_to_remove
                )

            NEW_AGENDA = PREVIOUS_AGENDA + [
                pick_new_agenda(AGENDAS_TREE, crnt_TOPIC_PERIOD)[0]
                for i in range(random.randint(agendas[0], agendas[1]))
            ]

            agendas_to_remove = random.choices(
                [i for i in range(len(NEW_AGENDA))], k=count_of_agendas_to_remove
            )

            NEW_AGENDA = [
                item for idx, item in enumerate(NEW_AGENDA) if idx in agendas_to_remove
            ]

        payload["agendas"] = NEW_AGENDA

    return payload


def get_personal_bias(
    PERSONAL_BIAS: dict, sample_size: int = 0, count: list[int] = None
) -> list[list[str]]:
    """
    This function returns a bias given a probability for all biases passed as
    a list. SAMPLE_SIZE is the number of unique samples to be taken from the
    bias'. COUNT is the number of each type of bias' to be assumed when
    sampling is carried out.

    Passing a SAMPLE_SIZE of 0 will return an enumerated list of all bias
    summaries but none of the detail.
    Omitting a list of count will assume each has a count of 1 (so each bias
    has equal probability of selection).
    """
    keys = list(PERSONAL_BIAS.keys())
    if sample_size == 0:
        return [[n, b] for n, b in enumerate([x.replace("_", " ") for x in keys])]

    if not count:
        count = [1 for i in keys]

    headers = random.sample(keys, counts=count, k=sample_size)

    return {h.replace("_", " "): PERSONAL_BIAS[h][0] for h in headers}


def list_to_enumerated_string(items: list[str]) -> str:
    """
    Convert a list of strings into an enumerated human-readable English list.

    Args:
    items (list of str): The list of strings to be converted.

    Returns:
    str: A string representing the list in an enumerated, human-readable
    English format.
    - A single item list will return the item itself.
    - A two-item list will return the items enumerated and joined by 'and'.
    - A list with more than two items will return the items enumerated,
    separated by commas with 'and' before the last item.

    Examples:
    >>> list_to_enumerated_string(['CHILDHOOD'])
    'CHILDHOOD'
    >>> list_to_enumerated_string(['CHILDHOOD', 'TEEN'])
    '1) CHILDHOOD and 2) TEEN'
    >>> list_to_enumerated_string(['CHILDHOOD', 'TEEN', 'TWENTYSOMETHINGS'])
    '1) CHILDHOOD, 2) TEEN and 3) TWENTYSOMETHINGS'
    """
    if not items:
        return ""
    elif len(items) == 1:
        return items[0]
    else:
        enumerated_items = [f"{i+1}) {item}" for i, item in enumerate(items)]
        if len(enumerated_items) == 2:
            return " and ".join(enumerated_items)
        else:
            return ", ".join(enumerated_items[:-1]) + " and " + enumerated_items[-1]


def select_relationships_of_pair(
    RELATIONSHIPS: dict, MAX_OVERLAP_OF_YEARS: int
) -> dict:
    """
    Given a dictionary of relationships, randomly select a collection of
    relationships between two characters (independent of character details).

    The relationships are selected such that they do not contradict.
    ('friends' and 'enemies' won't be selected together.
    'Grandparent|Grandchild' won't be selected with 'Parent|Child' and
    neither will be selected if the characters have less than 20 years
    age difference).
    """
    selected_relationships = []

    num_relationships = random.choice([1, 1, 1, 2, 2, 3])

    idx = 0

    while True:
        ks = sorted(RELATIONSHIPS.keys())
        k = random.sample(
            ks,
            counts=[
                int(100 * RELATIONSHIPS[i]["WEIGHTING"])
                for i in sorted(RELATIONSHIPS.keys())
            ],
            k=1,
        )[0]

        age_filter = False
        if "MINIMUM_AGE_DIFFERENCE" in RELATIONSHIPS[k]:
            if MAX_OVERLAP_OF_YEARS < RELATIONSHIPS[k]["MINIMUM_AGE_DIFFERENCE"]:
                age_filter = True

        other_relationship_filter = False
        if "CANNOT_BE" in RELATIONSHIPS[k]:
            if True in [
                x in set(selected_relationships)
                for x in set(RELATIONSHIPS[k]["CANNOT_BE"])
            ]:
                other_relationship_filter = True

        if (not age_filter) and (not other_relationship_filter):
            selected_relationships.append(k)
            idx += 1

        if (idx > num_relationships) or (idx > 100):
            break

    return [{k: RELATIONSHIPS[k]["DETAIL"]} for k in selected_relationships]


def get_character_pair(
    A_id: int, B_id: int, RELATIONSHIPS: dict, PERSONAL_BIAS: dict, CHARACTER_REPO: dict
) -> dict:
    """
    Given two integers A_id and B_id, this function will create a character
    pair.
        combo 1500 characters generates:
            sum([i for i in range(1500)]) =  1124250 pairs
    Without creating pairs based on the copy of the same base character.
    In addition getting the pair from CHARACTER_REPO, the system adds
    base data to build RELATIONSHIPS and PERSONAL_BIAS.
    """

    CHARACTER_PAIR = {"A": CHARACTER_REPO[A_id], "B": CHARACTER_REPO[B_id]}

    # Generate relationships
    MAX_OVERLAP_OF_YEARS = min(CHARACTER_PAIR["A"]["age"], CHARACTER_PAIR["B"]["age"])

    RELATIONSHIP_AGE_STRING = weighted_random_time_interval(
        MAX_OVERLAP_OF_YEARS, year_category_map()
    )

    RELATIONSHIP_AGE = year_category_map(RELATIONSHIP_AGE_STRING)

    relationship_start_decade_a = 10 * int(
        ((10 * int(CHARACTER_PAIR["A"]["age"] / 10)) - RELATIONSHIP_AGE) / 10
    )
    relationship_start_decade_b = 10 * int(
        ((10 * int(CHARACTER_PAIR["B"]["age"] / 10)) - RELATIONSHIP_AGE) / 10
    )

    relationship_epoc_a = [
        age_string_from_tens(i)
        for i in age_string_from_tens()
        if (i >= relationship_start_decade_a)
        and (i <= 10 * int(CHARACTER_PAIR["A"]["age"] / 10))
    ]
    relationship_epoc_b = [
        age_string_from_tens(i)
        for i in age_string_from_tens()
        if i >= relationship_start_decade_b
        and (i <= 10 * int(CHARACTER_PAIR["B"]["age"] / 10))
    ]

    return {
        **{
            "CHARACTER_RELATIONSHIP": select_relationships_of_pair(
                RELATIONSHIPS, MAX_OVERLAP_OF_YEARS
            ),
            "BIAS_PAIR": {
                "A": [
                    list(item) + [random.randint(-5, 5)]
                    for i in random.sample([3, 4, 5, 6], k=2)
                    for item in get_personal_bias(PERSONAL_BIAS, i).items()
                ],
                "B": [
                    list(item) + [random.randint(-5, 5)]
                    for i in random.sample([3, 4, 5, 6], k=2)
                    for item in get_personal_bias(PERSONAL_BIAS, i).items()
                ],
            },
            "RELATIONSHIP_AGE_STRING": RELATIONSHIP_AGE_STRING,
            "RELATIONSHIP_EPOCS_A": relationship_epoc_a,
            "RELATIONSHIP_EPOCS_B": relationship_epoc_b,
        },
        **CHARACTER_PAIR,
    }


def age_string_from_tens(ten: int = None) -> str:
    """
    get a category for a given
    multiple of ten (0 included).
    Pass 'None' to see all multiples.
    """
    if ten is None:
        return [0, 10, 20, 30, 40, 50, 60]

    return {
        0: "CHILDHOOD",
        10: "TEENS",
        20: "TWENTIES",
        30: "THIRTIES",
        40: "FORTIES",
        50: "FIFTIES",
        60: "SIXTIES",
    }[ten]


def age_tens_from_string(ageString: str = None) -> int:
    """
    get a multiple of ten given a category.
    Pass 'None' to see all categories.
    """
    if ageString is None:
        return [
            "CHILDHOOD",
            "TEENS",
            "TWENTIES",
            "THIRTIES",
            "FORTIES",
            "FIFTIES",
            "SIXTIES",
        ]
    return {
        "CHILDHOOD": 0,
        "TEENS": 10,
        "TWENTIES": 20,
        "THIRTIES": 30,
        "FORTIES": 40,
        "FIFTIES": 50,
        "SIXTIES": 60,
    }[ageString]


def next_epoch_given_current_epoch(epoch):
    """
    Given the string decade (epoch) return
    the next string decade.
    """
    decade = age_tens_from_string(epoch)
    if 60 > decade:
        return age_string_from_tens(decade + 10)
    else:
        None


def previous_epoch_given_current_epoch(epoch):
    """
    Given the string decade (epoch) return
    the previous string decade.
    """
    decade = age_tens_from_string(epoch)
    if 0 < decade:
        return age_string_from_tens(decade - 10)
    else:
        None


def get_last_processed_file(PARENT_FILE: str) -> Path:
    """
    This function returns the last processed character file.
    The information returned is:
        1) the decade processed in that file
        2) the numerical value of the start of that decade.
        3) the last element in the topic list processed (base zero)
        4) the full file path for that file.
    If the GENERATED_CHARACTERS folder doesn't exist under
    PARENT_FILE or if there are no files with "PROCESSED" in that
    directory, then None is returned.
    """

    # handle case where directory doesn't exist.
    if not Path(PARENT_FILE).joinpath("GENERATED_CHARACTERS").exists():
        return None

    FILES_ON_DISK = []
    for path in [
        item
        for item in Path(PARENT_FILE).joinpath("GENERATED_CHARACTERS").iterdir()
        if item.is_file() and str(item).find("PROCESSED") != -1
    ]:
        pIdx = str(path).find("PROCESSED")
        tIdx = str(path).find("TOPIC")
        p = str(path)[pIdx + 10 : tIdx - 1]
        FILES_ON_DISK.append(
            [p, age_tens_from_string(p), int(str(path)[tIdx + 6 : -5]), path]
        )

    latest_period = [
        i for i in FILES_ON_DISK if i[1] == max([i[1] for i in FILES_ON_DISK])
    ]

    # handle case where no file is found.
    if not latest_period:
        return None

    LAST_FILE_ON_DISK = [
        j for j in latest_period if j[2] == max([k[2] for k in latest_period])
    ][-1]

    print(f"last file: {LAST_FILE_ON_DISK[3]}")

    return LAST_FILE_ON_DISK


def pick_new_agenda(AGENDAS: dict, TOPIC_PERIOD: str) -> dict:
    """
    The pick_new_agenda function returns a new agenda item from the AGENDAS
    object. This selection is weighted 60:40 towards age related agendas for
    adults/teens but 80:20 for children. The age related selection is weighted
    so the 10 options in the current and following two 10 year periods have
    weights 4, 2 and 1 for each item in the respective groups. The number of
    options decreases with age as from 50, there is only 1 further option and
    from 60 there are no further age options.
    In this case the weights are [4, 2] and 4 respectively.
    """

    # here we use the given TOPIC_PERIOD to get the next two periods.
    # with the exception that childhood returns only childhood and teens.
    if TOPIC_PERIOD == "CHILDHOOD":
        epochs = ["CHILDHOOD", "TEENS"]
        age_weight = [8, 2]
    else:
        a = age_tens_from_string(TOPIC_PERIOD)
        epochs = [age_string_from_tens(s) for s in [a, a + 10, a + 20] if not s > 60]
        age_weight = [6, 4]

    # here we pick from age profiled goals weighted 4, 2 and 1 for now, 10
    # years and 20 years (with 10 choices in each).
    goals = []
    for i, e in enumerate(epochs):
        goals = goals + [
            [{a: AGENDAS[e][a]}, max(1, 4 - 2 * i)] for a in list(AGENDAS[e])
        ]

    # here we pick a random choice from the "all" bucket (49 choices)
    k = random.choice(sorted(AGENDAS["ALL"]))

    # Finally we return an agenda replacement with a 60% chance of being
    # somewhat age related.

    return random.choices(
        random.choices([i[0] for i in goals], [i[1] for i in goals], k=1)
        + [{k: AGENDAS["ALL"][k]}],
        weights=age_weight,
    )


def generate_base_character(flat_NATIONALITY_TREE: list) -> dict:
    """
    This function builds a base character profile given a distribution of
    nationalities (NationalitiesProbs) and a set of distributions for
    cultural/racial backgrounds given Nationalities.
    No event analysis keys are included here.
    """
    personality = {}
    #     Age: Influences generational perspectives and career stages.
    personality["age"] = random.choices([round(i + 20, 1) for i in range(45)], k=1)[0]
    #     Gender: Can affect dynamics depending on the cultural and
    #     organisational context.
    personality["gender"] = random.choices(["Male", "Female"], k=1)[0]
    #     Generate Nationality/race.
    nationality_and_culture = random.choices(
        flat_NATIONALITY_TREE, [i[2] for i in flat_NATIONALITY_TREE]
    )[0]
    #     Nationality: Adds layers of cultural diversity and potential language
    #     barriers.
    personality["nationality"] = nationality_and_culture[0]
    #     Race/Ethnicity: Might influence cultural backgrounds and experiences.
    personality["race or cultural background"] = nationality_and_culture[1]
    #     Sexual Orientation: Can affect personal and professional dynamics.
    personality["sexual orientation"] = random.choices(
        ["same sex", "opposite sex", "both"], [0.05, 0.85, 0.1], k=1
    )[0]

    return personality


def generate_TOPIC_detail(
    character: dict, inbound_params: dict, toggles: dict, topic_number: int
) -> dict:
    """
    This function takes a series of arguments and provides a dictionary object
    ready to send to the OpenAI API to obtain detailed TOPICS (generating
    'topic points'to use for character event generation.
    If the character files have not been previously processed for topics, it
    sets the function consider_immutables to False to disabled considering the
    distribution of topics previously processed with some basis on immutable
    characteristics of the characters. The key value is topic_number which the
     process which element in the list of broad topic targets to embellish.
    Full parameter specification:
     * character      ; dict : the details of the character to be embellished.
     * inbound_params ; dict : model specifications to be submitted in a batch.
     * toggles        ; dict : parameters controling the prompt generation
        keys:
        story_goal
            # Opening string setting out the broad goal of this prompt.
            # example:
            #     "You will provide details which will be used as the basis on
            #      which to build a story of a key childhood event for a
            #      character. "
        period_check
            # string advising period check example:
            #     "check the user provided YEAR_OF_BIRTH and establish a period
            #      over which their childhood would have have occurred."
        current_period
            # string summarising the current period (see acceptable definitions
            # using `age_string_from_tens'.
            # This is used as part of a key to access relevant topics.
            # example:
            #      'CHILDHOOD'
        consider_immutables
            # boolean to trigger using a statement that will add line with
            # instructions to consider the immutable characteristics of the
            # character.
            # example:
            #       True
        consider_age
            # boolean to trigger using a statement that will ask the model to
            # generate topic points relevent to the specific period of life for
            # the character when the topic occurs.
            # example:
            #       True
      * topic_number  ; int : the element in the base topic suggestions to
                                embellish.

    Returns
    params: the JSON object to be used in a batch element expressed as a python
    dictionary. (this is also saved to disk)

    """

    # Opening string setting out the broad goal of this prompt.
    # example:
    #     "You will provide details which will be used as the basis on which to
    # build a story of a key childhood event for a character. "
    story_goal = toggles["story_goal"]

    # string advising period check example:
    #     "check the user provided YEAR_OF_BIRTH and establish a period over
    # which their childhood would have have occurred."
    period_check = toggles["period_check"]

    # string summarising the current period (see acceptable definitions using
    # `age_string_from_tens'.
    # This is used as part of a key to access relevent topics.
    # example:
    #      'CHILDHOOD'
    current_period = toggles["current_period"]

    # Boolean to trigger using a statement that will add line with instructions
    # to consider the immutable characteristics of the character.
    # example:
    #       True
    consider_immutables = toggles["consider_immutables"]

    # boolean to trigger using a statement that will ask the model to generate
    # topic points relevent to the specific period of life for the
    # character when the topic occurs.
    # example:
    #       True
    consider_age = toggles["consider_age"]

    params = copy.deepcopy(inbound_params)

    TOPIC_PERIOD = current_period

    if consider_age:
        if TOPIC_PERIOD == "CHILDHOOD":
            age_string = "a character in their childhood."
        else:
            age_string = f"a character in their {TOPIC_PERIOD.lower()}."
    else:
        age_string = "their character."

    if topic_number == 0:
        consider_immutables = False  # for the first run, there are no previous
        # topics that could have been used with an
        # 'immutable' lense so no need to ensure
        # we aren't focusing too much on the same
        # immutables now.

    if consider_immutables:
        # PROCESSED_TOPIC_PERIODS = list_to_enumerated_string(
        #     [k for k in list(character.keys()) if k[:9] == "PROCESSED"]
        # )

        feature_immutables = (
            "\n3) consider the character details provided "
            "and once again update 'TOPIC_DETAIL' so although remaining "
            "broadly the same, the elements are now uniquely relevant to the "
            "experience  of a character of the given age and nationality, "
            "incorporating aspects of culture or gender. "
            "\n4) choose the new topic so ensure the focus for "
            "'TOPIC_DETAILS' is evenly spread over elements of their "
            "nationality, culture and gender when considered with the "
            "previous topics. "
            "\n5) create a new element 'TOPIC_POINTS' which is a list of "
            "specific items or elements for the new 'TOPIC_DETAIL' "
            "which would be relevent to someone in their "
            f"{age_string.lower()} \n6) "
        )
    else:
        feature_immutables = (
            "\n3) create a new element 'TOPIC_POINTS' which "
            "is a list of specific items or elements for the "
            "new 'TOPIC_DETAIL' relevant to "
            f"{age_string} \n4) "
        )

    system_message_generation_prompt = (
        " To achieve this, use the character details "
        "provided by the user in a JSON object as follows: "
        f"\n1) {period_check.strip()}"
    )

    system_message_generation_prompt = (
        story_goal.strip() + system_message_generation_prompt
    )

    system_message_generation_prompt = (
        f"{system_message_generation_prompt}"
        "\n2) identify any anachronisms needing correction for the "
        "'TOPIC_GROUP' or 'TOPIC_DETAIL'. If the 'TOPIC_GROUP' is "
        "anachronistic, provide an alternative for that "
        "and an appropriately updated 'TOPIC_DETAIL'. If only "
        "'TOPIC_DETAIL' is anachronistic, update that such that it is "
        "still appropriate for the overall 'TOPIC_GROUP'. "
    )

    system_message_generation_prompt = (
        system_message_generation_prompt + feature_immutables
    )

    system_message_generation_prompt = (
        f"{system_message_generation_prompt}"
        "after these updates, return the keys and associated "
        "values for 'TOPIC_GROUP', 'TOPIC_DETAIL' and 'TOPIC_POINTS' "
        "to the user as a JSON object. Include no other text."
    )

    if consider_immutables:
        previous_processed_topics = [
            k for k in list(character.keys()) if k[:9] == "PROCESSED"
        ]

        payload = {
            "NAME": character["NAME"],
            "age": character["age"],
            "gender": character["gender"],
            "nationality": character["nationality"],
            "race or cultural background": character["race or cultural background"],
            "sexual orientation": character["sexual orientation"],
        }
        for processed_topic in previous_processed_topics:
            payload[processed_topic] = character[f"PROCESSED_{TOPIC_PERIOD}_TOPICS"]

            payload["TOPIC_GROUP"] = character[TOPIC_PERIOD + "_TOPICS"][topic_number][
                "TOPIC_GROUP"
            ]

            payload["TOPIC_DETAIL"] = character[TOPIC_PERIOD + "_TOPICS"][topic_number][
                "TOPIC_DETAIL"
            ]
    else:
        payload = {
            "NAME": character["NAME"],
            "age": character["age"],
            "gender": character["gender"],
            "nationality": character["nationality"],
            "TOPIC_GROUP": character[TOPIC_PERIOD + "_TOPICS"][topic_number][
                "TOPIC_GROUP"
            ],
            "TOPIC_DETAIL": character[TOPIC_PERIOD + "_TOPICS"][topic_number][
                "TOPIC_DETAIL"
            ],
        }

    user_message_generation_prompt = (
        "```json\n" + json.dumps(payload, indent=4) + "\n```"
    )

    params["messages"] = [
        {"role": "system", "content": system_message_generation_prompt},
        {"role": "user", "content": user_message_generation_prompt},
    ]

    return params


def get_character_keys(epoch):
    """
    Return a list of keys grouped by type for any given epoch.
    """
    base = [
        "id",
        "NAME",
        "age",
        "gender",
        "nationality",
        "race or cultural background",
        "sexual orientation",
    ]
    stats = [
        "TABLE_PROFILE",
        "DEV_STAT_PROFILE",
        "PROFILE_DEV_PERCENTILES",
        "TABLE_BIG_FIVE",
        "DEV_STAT_BIG_FIVE",
        "BIG_FIVE_DEV_PERCENTILES",
    ]
    epochkeys = [
        f"{epoch}_EVENTS",
        f"{epoch}_TOPICS",
        f"{epoch}_AGENDAS",
        f"{epoch}_PROFILE",
        f"PROFILE_CHANGE_{epoch}",
    ]
    epochkeys = epochkeys[:-1] if epoch == "CHILDHOOD" else epochkeys

    current_story_element = f"{epoch}_STORY"

    prior_story_elements = [
        f"{age_string_from_tens(i)}_STORY"
        for i in range(0, 70, 10)
        if i < age_tens_from_string(epoch)
    ]

    return [base, epochkeys, stats, current_story_element, prior_story_elements]


def make_and_run_character_enrichment_batch_file(
    character_generation_system_prompt_fn,
    character_generation_user_prompt_fn,
    CHARACTER_REPO,
    current_epoch,
    input_batch_file_path,
    processed_batch_file_path,
):
    BATCH = []

    for i in range(len(CHARACTER_REPO)):
        char = CHARACTER_REPO[i]
        # do not generate a batch entry for any character younger
        # than the current epoch.
        if char["age"] <= age_tens_from_string(current_epoch):
            continue

        personality_generation_system_prompt = character_generation_system_prompt_fn(
            current_epoch
        )

        personality_generation_user_prompt = character_generation_user_prompt_fn(
            char, current_epoch
        )

        BATCH.append(
            {
                "custom_id": char["id"],
                "method": "POST",
                "url": "/v1/chat/completions",
                "body": {
                    **{
                        "model": "gpt-4o-mini",
                        "response_format": {"type": "json_object"},
                        "presence_penalty": 0,
                        "frequency_penalty": 0,
                        "temperature": 1,
                        "n": 1,
                    },
                    "messages": [
                        {
                            "role": "system",
                            "content": personality_generation_system_prompt,
                        },
                        {
                            "role": "user",
                            "content": "```json\n"
                            + json.dumps(personality_generation_user_prompt)
                            + "\n```",
                        },
                    ],
                },
            }
        )

    if len(BATCH) == 0:
        print("No one is old enough to be included in this batch. No action taken.")
        return True

    helpers.save_as_jsonl(BATCH, input_batch_file_path)
    openai_helpers.run_and_retrieve_batch_file(
        input_batch_file_path, processed_batch_file_path
    )

    print("Batch run and saved. ")

    return True


def generate_file_paths_for_character_process(
    TOPIC_NUMBER: int, TOPIC_PERIOD: str, HOME_PATH: str, TEMP_FOLDER: str = None
) -> list[Path]:
    """
    Generate the file-paths needed in the character generation process.
    """

    if not TEMP_FOLDER:
        PARENT_PATH = Path(HOME_PATH).joinpath("OpenAI", TEMP_FOLDER)
    else:
        PARENT_PATH = Path(HOME_PATH).joinpath("OpenAI")

    if TOPIC_NUMBER == 0 and TOPIC_PERIOD == "CHILDHOOD":
        source_character_file_address = Path(PARENT_PATH).joinpath(
            "GENERATED_CHARACTERS", "NAMED_BASE_CHARACTERS.json"
        )

    else:
        # last_processed_file list:
        #     1) the decade processed in that file
        #     2) the numerical value of the start of that decade.
        #     3) the last element in the topic list processed (base zero)
        #     4) the full file path for that file.
        last_processed_file = get_last_processed_file(PARENT_PATH)

    print(
        "last processed file\n"
        "--------------------\n"
        f"Decade: {last_processed_file[0]}\n"
        f"Decade n.: {last_processed_file[1]}\n"
        f"Previous topic: {last_processed_file[2]}\n\n"
        f"File path:\n    {last_processed_file[3]}\n"
    )

    _, _, _, source_character_file_address = last_processed_file

    # if TOPIC_NUMBER == 0 and not TOPIC_PERIOD == "CHILDHOOD":
    #     INPUT_TOPIC_PERIOD = age_string_from_tens(TOPIC_DECADE - 10)
    # else:
    #     INPUT_TOPIC_PERIOD = TOPIC_PERIOD

    batch_file_address = (
        f"BATCH_CHARACTERS_WITH_PROCESSED_{TOPIC_PERIOD}_TOPIC_"
        f"{TOPIC_NUMBER:02}.jsonl"
    )
    batch_file_address = Path(PARENT_PATH).joinpath(
        "GENERATED_CHARACTERS", "batches", batch_file_address
    )

    model_results_file_address = (
        f"RESULTS-{TOPIC_PERIOD}_TOPIC_MODEL_UPDATES_{TOPIC_NUMBER:02}.jsonl"
    )
    model_results_file_address = Path(PARENT_PATH).joinpath(
        "GENERATED_CHARACTERS", "batches", model_results_file_address
    )

    final_result_file_name = (
        f"NAMED_BASE_CHARACTERS_WITH_PROCESSED_{TOPIC_PERIOD}"
        f"_TOPIC_{TOPIC_NUMBER:02}.json"
    )
    final_result_file_name = Path(PARENT_PATH).joinpath(
        "GENERATED_CHARACTERS", final_result_file_name
    )

    print(
        f"input data: {batch_file_address}\n"
        f"batch file: {model_results_file_address}\n"
        f"processed result: {final_result_file_name}\n"
        "--------------------\n"
    )

    return [
        source_character_file_address,
        batch_file_address,
        model_results_file_address,
        final_result_file_name,
    ]


def generate_character_topic_batch_file(
    character_file_path: Union[Path, str],
    batch_file_path: Union[Path, str],
    toggles: dict,
    model_parameters: dict,
    TOPIC_NUMBER: int,
    TOPIC_PERIOD: str,
) -> bool:
    """
    Given file paths and prompt parameters, generate a series of prompts and
    save to a batch file.
    If this is the first topic in a series (TOPIC_NUMBER = 0) then we must
    first generate topics and events for each character in the new
    TOPIC_PERIOD.
    """

    characters = json.loads(helpers.read_text_file(character_file_path))

    TOPIC_MODEL_UPDATES = []

    update_count = 0
    # this controls for situations where we are looking to process say
    # the 9th topic (topic id 8 - remember base zero)
    # and no character has more than 8 topics.
    found_character_with_this_number_of_topics = False

    idx_prefix = random.choice(string.ascii_letters + string.digits)
    for i, char in enumerate(characters):
        if len(char[f"{TOPIC_PERIOD}_TOPICS"]) > TOPIC_NUMBER:
            found_character_with_this_number_of_topics = True
            update_count += 1
            char["YEAR_OF_BIRTH"] = int(str(date.today())[:4]) - char["age"]
            custom_id = (
                str(i)
                + "_"
                + idx_prefix
                + "_"
                + (char["NAME"])
                .replace("-", " ")
                .replace("_", " ")
                .title()
                .replace(" ", "")
            )
            TOPIC_MODEL_UPDATES.append(
                {
                    "custom_id": custom_id,
                    "method": "POST",
                    "url": "/v1/chat/completions",
                    "body": generate_TOPIC_detail(
                        char,
                        model_parameters,
                        toggles,
                        TOPIC_NUMBER,
                    ),
                }
            )

    if not found_character_with_this_number_of_topics:
        # No character has this many topics. Exit this process."
        return False

    # Save down the batch file. This process will not
    # overwrite by default and will use existing files in preference
    # to new ones if they are produced in the process.
    helpers.save_as_jsonl(TOPIC_MODEL_UPDATES, batch_file_path)

    print(f"Created and saved a batch with {update_count} characters.")

    return True


def enrich_character_topics(
    model_results_file_path: Union[Path, str],
    character_file_path: Union[Path, str],
    final_result_file_path: Union[Path, str],
    TOPIC_PERIOD: str,
    TOPIC_NUMBER: int,
    toggles: dict,
) -> dict:
    """
    Build a dictionary from the returned data and enrich the character
    records.
    """
    RESULTS_DATA = helpers.read_jsonl(model_results_file_path)

    print("Building results dictionary and enriching profiles. ")
    RESULTS_KEY_TOPIC_MODEL_DICT = {}
    for idx, res in enumerate(RESULTS_DATA):
        k = (
            res["custom_id"][: res["custom_id"].find("_")]
            + "_"
            + res["custom_id"][res["custom_id"].find("_") + 3 :]
        )
        RESULTS_KEY_TOPIC_MODEL_DICT[k] = json.loads(
            RESULTS_DATA[idx]["response"]["body"]["choices"][0]["message"]["content"]
        )

    # Load the original character data.
    characters = json.loads(helpers.read_text_file(character_file_path))

    # Integrate the new data into the original data.
    current_topic_keys = [
        f"PROCESSED_{TOPIC_PERIOD}_TOPIC_DETAIL",
        f"PROCESSED_{TOPIC_PERIOD}_TOPIC_GROUP",
        f"PROCESSED_{TOPIC_PERIOD}_TOPIC_POINTS",
    ]

    k = f"PROCESSED_{TOPIC_PERIOD}_TOPICS"

    for char in characters:
        id = char["id"]
        # ensure that we only attempt to update character
        # profiles which have at least TOPIC_NUMBER of
        # topics.
        if id in list(RESULTS_KEY_TOPIC_MODEL_DICT.keys()):
            crnt_dict = {}
            for v in current_topic_keys:
                crnt_dict[v] = RESULTS_KEY_TOPIC_MODEL_DICT[id][
                    "TOPIC_" + v[::-1][: v[::-1].find("_")][::-1]
                ]

            crnt_dict["settings"] = toggles

            # add topics & events.
            if k in char:
                char[k].append(crnt_dict)
            else:
                char[k] = [crnt_dict]

    # Save the enriched character file. This process will not
    # overwrite by default and will use existing files in preference
    # to new ones if they are produced in the process.
    helpers.save_as_json(characters, final_result_file_path)

    print(f"Process complete for topic {TOPIC_NUMBER}")

    return characters


def update_character_profile(
    TOPIC_PERIOD: int,
    character_file_path: Union[Path, str],
    toggles: dict,
    AGENDAS_TREE: dict,
    flat_LIFE_EVENTS: list,
    flat_TOPICS_TREE: list,
) -> bool:
    """
    This function updates an existing character profile adding basic topics and
    5events. It also updates the character metrics randomly in accordance with
    the changes expected at the given age.

    Note that the nature of this process means the updated data will be
    first inserted into the file just before a new decade. That means the
    TEENS data will be inserted into the last CHILDHOOD file and so on.
    """
    # we are starting a new decade and need to adjust the character
    # parameters and generate new topics.
    decade_age = age_tens_from_string(TOPIC_PERIOD)
    previous_period = age_string_from_tens(decade_age - 10)

    t = f"{TOPIC_PERIOD}_TOPICS"
    e = f"{TOPIC_PERIOD}_EVENTS"
    a = f"{TOPIC_PERIOD}_AGENDA"
    p = f"{TOPIC_PERIOD}_PROFILE"

    print(f"update_character_profile: topic period: {TOPIC_PERIOD}")

    characters = json.loads(helpers.read_text_file(character_file_path))

    for i, char in enumerate(characters):
        if char["age"] >= decade_age:
            if (prev_agenda := previous_period + "_AGENDA") in char:
                prev_agenda = char[prev_agenda]
            else:
                prev_agenda = None

            # generate random base topics, events and agendas.
            topics_and_events = generate_topics_and_events(
                flat_LIFE_EVENTS,
                flat_TOPICS_TREE,
                AGENDAS_TREE,
                toggles["topic_count_range"],
                toggles["event_count_range"],
                toggles["agenda_count_range"],
                prev_agenda,
                TOPIC_PERIOD,
            )
            # update the randomly base generated topics, events and agendas.
            char[t] = topics_and_events["topics"]
            char[e] = topics_and_events["events"]
            char[a] = topics_and_events["agendas"]
            # update the personality profile.
            char[p] = initialize_or_update_profile(
                decade_age, char[f"{previous_period}_PROFILE"]
            )
        # ensure the character ID is present.
        if "id" not in char:
            id = (
                str(i)
                + "_"
                + (char["NAME"])
                .replace("-", " ")
                .replace("_", " ")
                .title()
                .replace(" ", "")
            )
            char["id"] = id

    # save down the enriched character data. This process will overwrite
    # by default and will use existing files in preference to new ones
    # if they are produced in the process.
    helpers.save_as_json(characters, character_file_path, False)

    print(f"Character updated and saved to:\n{character_file_path}")

    return True


def topic_processing(
    home_path: Union[Path, str],
    toggles: dict,
    model_parameters: dict,
    TOPIC_NUMBER: int,
    flat_LIFE_EVENTS: list,
    flat_TOPICS_TREE: list,
    AGENDAS_TREE: dict,
    BATCH_ONLY: bool = False,
    TEMP_FOLDER: str = None,
) -> dict:
    """
    Enrich a full batch of characters using OpenAI to enrich the topics
    randomly selected for those characters. This results in production of a
    full specification for each character.
    """
    TOPIC_PERIOD = toggles["current_period"]

    # first generate the paths required for files in this process.
    (
        character_file_path,
        batch_file_path,
        model_results_file_path,
        final_result_file_path,
    ) = generate_file_paths_for_character_process(
        TOPIC_NUMBER, TOPIC_PERIOD, home_path, TEMP_FOLDER
    )

    # exit if the needed data isn't available or there is danger of
    # existing work being overwritten.
    if not character_file_path.exists() or final_result_file_path.exists():
        print(
            f"NAMED_BASE_CHARACTERS_WITH_PROCESSED_TOPIC_{TOPIC_NUMBER:02}"
            ".json already exists or "
            "\n{character_file_path} does not exist. "
        )

        return -1

    if TOPIC_NUMBER == 0:
        print(f"topic_processing: topic number (should be 0): {TOPIC_NUMBER}")
        # we are starting a new decade and need to adjust the character
        # parameters and generate new topics/events.
        # These will be saved to disk in the character file to be used
        # for the new data.
        update_character_profile(
            TOPIC_PERIOD,
            character_file_path,
            toggles,
            AGENDAS_TREE,
            flat_LIFE_EVENTS,
            flat_TOPICS_TREE,
        )

    if not batch_file_path.exists():
        print(
            f"Starting process for topic {TOPIC_NUMBER}:\n"
            "    Generating batch payload.\n\n"
        )
        generate_character_topic_batch_file(
            character_file_path,
            batch_file_path,
            toggles,
            model_parameters,
            TOPIC_NUMBER,
            TOPIC_PERIOD,
        )
    else:
        print(
            f"batch file\n{batch_file_path}\n"
            f"for topic {TOPIC_NUMBER} already exists.\n"
            "It has not been recreated.\n"
        )

    # if the batch file does not exist by this point
    # it is due to the fact that no topic lists
    # are longer than TOPIC_NUMBER.
    if not batch_file_path.exists():
        print(
            f"No characters have {1 + TOPIC_NUMBER} topics \n"
            f"in their {TOPIC_PERIOD.lower()}.\n"
            "Exiting this topic enrichment."
        )

        return False

    if BATCH_ONLY:
        print(
            "BATCH_ONLY set to True.\n"
            "Finishing here after batch processes complete. "
        )
        return batch_file_path
    # -------------------------------
    # Now submit the batch to run and save down when complete.
    if not model_results_file_path.exists():
        print(f"Starting process for topic {TOPIC_NUMBER}:\n" "    topic payload.")

        openai_helpers.run_and_retrieve_batch_file(
            batch_file_path, model_results_file_path
        )

    else:
        print(
            f"results file\n{model_results_file_path}\n"
            f"for topic {TOPIC_NUMBER}"
            " already exists.\n"
            "It has not been recreated.\n"
        )

    print(
        f"topic batch {TOPIC_NUMBER} completed at local time: "
        f"{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    )

    # -------------------------------
    # Build a dictionary from the returned data and enrich the character
    # records.
    print(
        "Building results dictionary and enriching profiles:\n    "
        f"{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    )

    new_profile = enrich_character_topics(
        model_results_file_path,
        character_file_path,
        final_result_file_path,
        TOPIC_PERIOD,
        TOPIC_NUMBER,
        toggles,
    )

    return new_profile


def enrich_profile(
    character_generation_system_prompt_fn,
    character_generation_user_prompt_fn,
    current_epoch,
    input_character_repo,
    input_batch_file_path,
    processed_batch_file_path,
    final_profile_output,
    data_applicator,
):
    """
    This function uses a given system prompt to update base character files, creating
    stories which match the given character.
    """

    # for current_epoch in epochs:

    CHARACTER_REPO = json.loads(helpers.read_text_file(input_character_repo))

    make_and_run_character_enrichment_batch_file(
        character_generation_system_prompt_fn,
        character_generation_user_prompt_fn,
        CHARACTER_REPO,
        current_epoch,
        input_batch_file_path,
        processed_batch_file_path,
    )

    PROCESSED_BATCH_FULL_CHARACTER = helpers.read_jsonl(processed_batch_file_path)

    output, err_records, err_data = (
        openai_helpers.get_json_content_list_from_open_ai_return(
            PROCESSED_BATCH_FULL_CHARACTER
        )
    )

    print(f"successfully created record count: {len(output)}")
    print(f"\nfailed record count: {len(err_records)}\n")

    redo_input_batch_file_path = helpers.add_prefix_to_filename(
        input_batch_file_path, "REDO_"
    )

    redo_processed_batch_file_path = helpers.add_prefix_to_filename(
        processed_batch_file_path, "REDO_"
    )

    # if there are errors (but nothing indicative of an issue with the prompt), redo
    # the failed prompts.
    if (len(err_records) != 0) and (len(err_records) < 100):
        REDO_CHARACTER_REPO = [
            CHARACTER_REPO[int(err[0][: err[0].find("_")])] for err in err_records
        ]
        make_and_run_character_enrichment_batch_file(
            character_generation_system_prompt_fn,
            character_generation_user_prompt_fn,
            REDO_CHARACTER_REPO,
            current_epoch,
            redo_input_batch_file_path,
            redo_processed_batch_file_path,
        )

        REDO_PROCESSED_BATCH_FULL_CHARACTER = helpers.read_jsonl(
            redo_processed_batch_file_path
        )

        redo_output, redo_err_records, redo_err_data = (
            openai_helpers.get_json_content_list_from_open_ai_return(
                REDO_PROCESSED_BATCH_FULL_CHARACTER
            )
        )

        # if the redo went well (no remaining errors), merge the redo with existing
        # records and save.
        NEW_REPO = []
        if len(redo_err_records) == 0:
            print(f"{current_epoch} process successful.")
            STORY_OUTPUT = {i["id"]: i for i in output + redo_output}
            new_id_list = list(STORY_OUTPUT.keys())
            for char in CHARACTER_REPO:
                if char["id"] in new_id_list:
                    new_record = STORY_OUTPUT[char["id"]]
                    NEW_REPO.append(data_applicator(new_record, char, current_epoch))
                else:
                    NEW_REPO.append(char)

            helpers.save_as_json(
                NEW_REPO,
                final_profile_output,
            )
            return redo_output + output

        else:
            # if we still have errors, save what we have so far and investigate further.
            print(
                f"{current_epoch} process resulted in some errors. "
                f"See PARTIAL_{current_epoch}_STORY_REPO.json."
            )
            STORY_OUTPUT = {i["id"]: i for i in output + redo_output}
            new_id_list = list(STORY_OUTPUT.keys())
            for char in CHARACTER_REPO:
                if char["id"] in new_id_list:
                    new_record = STORY_OUTPUT[char["id"]]
                    NEW_REPO.append(data_applicator(new_record, char, current_epoch))
                else:
                    NEW_REPO.append(char)

            helpers.save_as_json(
                NEW_REPO,
                final_profile_output,
            )

            return {
                "success": redo_output + output,
                "errors": {
                    "error_record": redo_err_records,
                    "error_data": redo_err_data,
                },
            }

    elif len(err_records) == 0:
        print("No redos: no errors on first run. ")

        NEW_REPO = []

        print(f"{current_epoch} process successful.")
        STORY_OUTPUT = {i["id"]: i for i in output}
        new_id_list = list(STORY_OUTPUT.keys())
        for char in CHARACTER_REPO:
            if char["id"] in new_id_list:
                new_record = STORY_OUTPUT[char["id"]]
                NEW_REPO.append(data_applicator(new_record, char, current_epoch))
            else:
                NEW_REPO.append(char)
        helpers.save_as_json(
            NEW_REPO,
            final_profile_output,
        )

        return output

    else:
        print("lots of errors on first run. Investigation needed - no redo attempted.")
        return {"error_record": err_records, "error_data": err_data}
        
        
