#!/usr/bin/env python
"""
OpenAI API Interaction and Batch Processing Module

This module provides functions and classes for interacting with the OpenAI API,
including streaming responses from an assistant, handling batch jobs, and
listing files and batches.

It uses the OpenAI SDK to manage API keys, event handling, and data processing.

******************************************************************************
Note that access to the OpenAI endpoint requires a key set as environmental
variable "OPENAI_API_KEY".
If this environmental variable is not present, access to OpenAI endpoints will
be denied.
******************************************************************************

Classes:
    EventHandler
        Handles events in the response stream from the OpenAI Assistant.

Functions:
    use_assistant(assistant_id, prompt, target_directory)
        Uses the OpenAI Assistant to process a given prompt and saves the
        results to a specified directory.

    list_batches()
        Returns a list of all batches on the current client, handling
        pagination.

    list_files()
        Returns a list of all files on the current client, handling pagination.

    get_json_content_list_from_open_ai_return()
        Given a JSONL object, this function strips and extracts the object under
        'content'. It also provides reporting on any errors.

    create_completion_endpoint_batch_job_with_jsonl_FilePath()
        Creates a batch job on the OpenAI endpoint "/v1/chat/completions"
        using a JSONL file.

    get_batch_status(batch_id)
        Returns the status of a batch given a batch ID string.

    retrieve_batch_results(sink_file_address, output_file_id)
        Returns results from a batch job given the batch job's output file ID
        string.

    check_and_wait_for_completion_then_download(batch_id, sink_file_address)
        Checks on a running batch, waits until it is completed, and downloads
        the results.


    run_and_retrieve_batch_file
        This function serves to bring together the creation of the batch file
        and it's processing using the OpenAI endpoint.

Example usage:

    # Use the assistant
    assistant_id = "your-assistant-id"
    prompt = "Hello, how can I help you?"
    target_directory = Path("/path/to/target/directory")
    result = use_assistant(assistant_id, prompt, target_directory)

    # List all batches
    batches = list_batches()

    # List all files
    files = list_files()

    # Create a batch job
    local_jsonl_source_file = "/path/to/source/file.jsonl"
    batch_job = create_completion_endpoint_batch_job_with_jsonl_FilePath(
        local_jsonl_source_file
    )

    # Get batch status
    batch_id = batch_job.id
    status = get_batch_status(batch_id)

    # Retrieve batch results
    sink_file_address = "/path/to/sink/file.json"
    output_file_id = status.output_file_id
    results = retrieve_batch_results(sink_file_address, output_file_id)

    # Check and wait for batch completion, then download results
    results = check_and_wait_for_completion_then_download(
        batch_id, sink_file_address
    )

Example usage of run_and_retrieve_batch_file with existing batch file:
    Given a batch file at sink_file_address, we specify a response from OpenAI to be
    saved to file address output_file_id.
    run_and_retrieve_batch_file(sink_file_address, output_file_id)
"""

import datetime
import json
import os
import time
from pathlib import Path

from typing import Any
from typing_extensions import override
import openai
from openai import AssistantEventHandler, OpenAI

from openai.types import FileObject, Batch
from openai.pagination import SyncCursorPage
from openai.types.beta.thread import Thread

from openai.types.beta.assistant import Assistant

# from openai.resources.batches import Assistant
from openai.types.beta.threads import Text, TextDelta, Message, TextDeltaBlock
from openai.types.beta.threads.runs import ToolCall, ToolCallDelta

# typing for data objects returned from OPENAI (specified in openai_types.py).
from custom_types import (
    OPEN_AI_BATCH_OUTPUT,
    OPEN_AI_BODY,
    OPEN_AI_CHOICE,
    OPEN_AI_MESSAGE,
    OPEN_AI_RESPONSE
)

# Set your OpenAI API key
openai.api_key = os.getenv("OPENAI_API_KEY")
client: OpenAI = OpenAI()


# Assistant: streamed response
# --------------------------------------
# First, we create an EventHandler class to define
# how we want to handle the events in the response stream.
class EventHandler(AssistantEventHandler):
    @override
    def on_text_created(self, text: Text) -> None:
        """
        Handles the event where text is created in the assistant response.

        Args:
            text (str): The created text content.
        """
        print("\nassistant > ", end="", flush=True)

    @override
    def on_text_delta(self, delta: TextDelta, snapshot: Text):
        """
        Handles the event where a delta (partial text response) is received.

        Args:
            delta (Any): The delta object containing the text changes.
            snapshot (Any): A snapshot of the current state.
        """
        print(delta.value, end="", flush=True)

    @override
    def on_tool_call_created(self, tool_call: ToolCall):
        """
        Handles the event when a tool call is created.

        Args:
            tool_call (Any): The tool call details.
        """
        print(f"\nassistant > {tool_call.type}\n", flush=True)

    @override
    def on_tool_call_delta(self, delta: ToolCallDelta, snapshot: ToolCall):
        """
        Handles the event when a tool call delta (partial update) is received.

        Args:
            delta (Any): The delta object with tool call updates.
            snapshot (Any): A snapshot of the current state.
        """
        if delta.type == "code_interpreter" and delta.code_interpreter:
            if delta.code_interpreter.input:
                print(delta.code_interpreter.input, end="", flush=True)
            if delta.code_interpreter.outputs:
                print("\n\noutput >", flush=True)

                for output in delta.code_interpreter.outputs:
                    if output.type == "logs":
                        print(f"\n{output.logs}", flush=True)


@override
def use_assistant(
    assistant_id: str, prompt: str, target_directory: Path
) -> list[str | None]:
    """
    Interacts with the OpenAI Assistant to create a thread, send a prompt, and save the results.

    Args:
        assistant_id (str): The ID of the assistant to use.
        prompt (str): The user-provided prompt.
        target_directory (Path): The directory to save the results JSON.

    Returns:
        list[str | None]: A list containing thread message ID, thread ID, and assistant ID.
    """
    # Create a thread
    thread: Thread = client.beta.threads.create()
    if not thread or not hasattr(thread, "id"):
        raise ValueError("Thread creation failed or thread ID is missing.")

    # Create a message
    message: Message = client.beta.threads.messages.create(
        thread_id=thread.id, role="user", content=prompt
    )
    if not message or not hasattr(message, "id"):
        raise ValueError("Message creation failed or message ID is missing.")

    # Retrieve the assistant
    my_assistant: Assistant = client.beta.assistants.retrieve(assistant_id)
    if not my_assistant or not hasattr(my_assistant, "id"):
        raise ValueError("Assistant retrieval failed or assistant ID is missing.")

    # Stream the assistant's response using EventHandler
    with client.beta.threads.runs.stream(
        thread_id=thread.id,
        assistant_id=my_assistant.id,
        event_handler=EventHandler(),
    ) as stream:
        stream.until_done()

    # Get the thread messages
    thread_messages: SyncCursorPage[Message] = client.beta.threads.messages.list(
        thread.id
    )
    if not thread_messages or not hasattr(thread_messages, "data"):
        raise ValueError(
            "Failed to retrieve thread messages or thread messages data is missing."
        )

    # Extract and process results
    try:
        obj: list[str | None] = [
            content.text.value
            for message in thread_messages.data
            for content in message.content
            if isinstance(content, TextDeltaBlock) and content.text is not None
        ]
    except (IndexError, AttributeError) as e:
        raise ValueError(f"Error processing thread messages: {e}")

    # format when obj[0] and obj[1] are populated.
    if obj[0] and obj[1]:
        results_dict: dict[str, dict[str, object]] = {
            obj[1]: {
                "value": json.loads(
                    obj[0].replace("```json", "").replace("```", "").strip()
                ),
                "id": thread_messages.data[0].id,
                "thread_id": thread_messages.data[0].thread_id,
                "assistant_id": thread_messages.data[0].assistant_id,
            }
        }

        # Save results as JSON
        file_path = target_directory.joinpath(obj[1].replace(" ", "") + ".json")
        with open(file_path, "w", encoding="utf-8") as file:
            json.dump(results_dict, file, indent=4)

        return [
            thread_messages.data[0].id,
            thread_messages.data[0].thread_id,
            thread_messages.data[0].assistant_id,
        ]
    else:
        raise ValueError(
            "Error processing thread messages:\n" + f"key: {obj[0]}\nvalue: {obj[1]}"
        )


# Update the fetch_page function
def fetch_page(cursor: str | None = None) -> SyncCursorPage[Batch] | None:
    params = {}
    """
    Get a page when given a cursor.
    """
    if cursor:
        params["cursor"] = cursor

    response = client.batches.list(**params)
    return response


# Update the list_batches function
def list_batches() -> list[Batch]:
    """
    This function returns a list of all the batches on the current client.

    It handles the scenario where there are multiple pages of batches.
    """
    # Initial fetch
    response: SyncCursorPage[Batch] | None = fetch_page()

    # If no response, return an empty list
    if not response:
        return []

    # Process the first page of data
    data: list[Batch] = response.data  # Native list of Batch objects

    # Check if there are additional pages and fetch them
    while response.has_next_page():
        response = response.get_next_page()  # Fetch the next page
        if not response:
            break
        data.extend(response.data)

    # Return the aggregated data
    return data


# --------------------------------------
# Batch jobs
# ______________________________________
# The below functions handle:
# * the creation of a batch job,
# * monitoring the status and retrieving results from a batch job
# * retrieve_batch_results


def get_json_content_list_from_open_ai_return(
    prompt_return_list: OPEN_AI_BATCH_OUTPUT,
) -> tuple[list[dict[str, Any]], list[tuple[str, int, str]], list[list[str]]]:
    """
    Given a return from open_ai, this function returns the content from
    the objects in jsonl together with reporting on any non-compliant
    JSON returns in a list of output, 'error_records' and 'error_data'.
    """
    output: list[dict[str, Any]] | None = []
    err_records: list[tuple[str, int, str]] | None = []
    err_data: list[list[str]] | None = []

    for i in range(len(prompt_return_list)):
        id: str = prompt_return_list[i].get("custom_id")

        response: OPEN_AI_RESPONSE | None = prompt_return_list[i].get("response", None)
        body: OPEN_AI_BODY | None = response.get("body", None)
        choice: OPEN_AI_CHOICE | None = body.get("choices", [None])[0]
        message: OPEN_AI_MESSAGE | None = choice.get("message", None)
        content: str | None = message.get("content", None)

        if not response:
            # Handle missing payload
            print(f"KeyError: Missing response in record {i}")
            err_records.append((id, i, "Missing response dict"))
            err_data.append([""])
            continue

        if not content:
            # Handle missing prompt response.
            print(f"KeyError: Missing or malformed content in record {i}")
            err_records.append((id, i, "Missing content string"))
            err_data.append([str(response)])
            continue

        try:
            # Attempt to load the JSON content
            processed_content = json.loads(content)

        except json.JSONDecodeError as e:
            # Capture JSON decoding errors
            print(f"JSON Decode Error on record {i}: {e}")
            err_records.append((id, i, str(e)))
            err_data.append([str(response)])
            continue

        except Exception as e:
            # Capture any unexpected error during JSON loading
            print(f"General error from json.loads on record {i}: {e}")
            err_records.append((id, i, str(e)))
            err_data.append([str(response)])
            continue

        try:
            # Construct the parsed JSON with additional ID field
            parsed_json: dict[str, Any] = {"id": id, **processed_content}

        except Exception as e:
            # Handle any error during dictionary construction
            print(f"Error during dictionary construction on record {i}: {e}")
            err_records.append((id, i, str(e)))
            err_data.append([id, processed_content])
            continue

        # If everything is successful, append to output
        output.append(parsed_json)

    return output, err_records, err_data


def create_completion_endpoint_batch_job_with_jsonl_FilePath(
    local_jsonl_source_file: Path | str,
):
    """
    This function creates a batch job on the OpenAI
    endpoint "/v1/responses".
    """

    # Upload the file
    batch_file: FileObject = client.files.create(
        file=open(local_jsonl_source_file, "rb"), purpose="batch"
    )

    # Create the job
    batch_job: Batch = client.batches.create(
        input_file_id=batch_file.id,
        endpoint="/v1/responses",    #"/v1/chat/completions",
        completion_window="24h"
    )
    print(f"Created batch with id: {batch_job.id}")

    return batch_job


def get_batch_status(batch_id: str) -> Batch:
    """
    This function returns the status of a
    batch given a batch id string.
    """
    return client.batches.retrieve(batch_id)


def retrieve_batch_results(
    sink_file_address: str | Path, output_file_id: str
) -> list[str] | None:
    """
    This function returns results from a batch job given the
    batch_job.output_file_id string.
    """

    result = client.files.content(output_file_id).content

    with open(sink_file_address, "wb") as file:
        _ = file.write(result)

    # Loading data from saved file
    RESULTS_DATA: list[str] = []
    with open(sink_file_address, "r") as file:
        for line in file:
            # Parsing the JSON string into a dict and appending to the list of
            # results
            json_object = json.loads(line.strip())
            RESULTS_DATA.append(json_object)

            return RESULTS_DATA


def check_and_wait_for_completion_then_download(
    batch_id: str, sink_file_address: str | Path
):
    """
    This function checks on a running batch and waits until it is completed
    to download and return the results.
    """
    while True:
        response = get_batch_status(batch_id)
        completed_at = response.completed_at
        batch_err = response.errors

        if completed_at:
            print(f"Batch {batch_id} completed at {completed_at}")

            # Proceed to extract the file
            if isinstance(response.output_file_id, str):
                output_file_id: str = response.output_file_id
                RESULTS_DATA = retrieve_batch_results(sink_file_address, output_file_id)

                return RESULTS_DATA
                break

        elif batch_err is None:
                current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                message = (
                    f"[{current_time}]: Batch {batch_id} not completed "
                    " yet, waiting for another minute..."
                )
                print(message)
                time.sleep(60)  # Wait for 1 minute before checking again
        else:
            message = f"batch error reported and process terminated.\n{batch_err}"
            break

    return False


def run_and_retrieve_batch_file(
    batch_file_path: Path | str, model_results_file_path: Path | str
) -> bool:
    """
    This function serves to bring together the creation of the batch file
    and it's processing using the OpenAI endpoint.
    'run_chacter_topic_batch_file
    Args:
        batch_file_path (path or string):
            path to the input batch-file
        model_results_file_path (path or string):
            path to the output results file
    """
    print(
        "Batch process started at local time: "
        + f"{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
        + f"Processing {batch_file_path}"
    )

    # set up the batch job
    batch_job: Batch = create_completion_endpoint_batch_job_with_jsonl_FilePath(
        batch_file_path
    )

    # wait for the job to complete and download it.
    _ = check_and_wait_for_completion_then_download(
        batch_job.id, model_results_file_path
    )

    return batch_job.id


# -----------------
# End of Batch jobs

#  LocalWords:  Args noutput nvalue rb SyncCursorPage SyncCursorPageProtocol TypedDict
#  LocalWords:  logprobs
