
from pandas import DataFrame

# gather 'current' information on openAI models.  (as of 2023.11.21)

def open_ai_model_details():
    """
    This function returns a pandas dataframe consolidating model information accurate as of 2023.11.21,
    Note that this information is the subject of frequent change. 
    
    Tier 1 and Tier 2 are access levels for the open AI API. Tier two gives greater access but is dependent on spending USD50
    per month. 
      -  TPM: A limit on the number of Tokens per minute that can be processed by any given account
      -  RPM:
      -  RPD: A limit on the number of Tokens per day that can be processed by an account
    """
    print("\nData captured on Nov 21 2023.\n")
    model_ref = ["gpt-4-1106-preview", "gpt-4-vision-preview", "gpt-4", "gpt-4-32k", "gpt-4-0613", "gpt-4-32k-0613"]

    description = [
        "GPT-4 TurboNew\nThe latest GPT-4 model with improved instruction following, JSON mode, reproducible outputs, parallel function calling, and more. Returns a maximum of 4,096 output tokens. This preview model is not yet suited for production traffic. ", 
        "GPT-4 Turbo with visionNew\nAbility to understand images, in addition to all other GPT-4 Turbo capabilties. Returns a maximum of 4,096 output tokens. This is a preview model version and not suited yet for production traffic. ", 
        "Currently points to gpt-4-0613. See continuous model upgrades. ", 
        "Currently points to gpt-4-32k-0613. See continuous model upgrades. ", 
        "Snapshot of gpt-4 from June 13th 2023 with improved function calling support. ", 
        "Snapshot of gpt-4-32k from June 13th 2023 with improved function calling support. "]
    
    max_tokens = [4096, 4096, 8192, 32768, 8192, 8192]
    context = [128000, 128000, 8192, 32768, 8192, 32768]
    training_data =['2023.04', '2023.04', '2021.09', '2021.09', '2021.09', '2021.09']
    input_cost = [0.01, 0.01, 0.03, 0.06, 0.03, 0.06]
    output_cost = [0.03, 0.03, 0.06, 0.12, 0.06, 0.12]

    # Tier 1
    # ------
    TPM1 = [150000, 10000, 10000, 10000, 10000, 10000]
    RPM1 = [500, 50, 500, 500, 500, 500]
    RPD1 = [10000, 100, 0, 0, 0, 0]

    # Tier 2
    # ------
    TPM2 = [150000, 10000, 10000, 10000, 10000, 10000]
    RPM2 = [500, 50, 500, 500, 500, 500]
    RPD2 = [10000, 100, 0, 0, 0, 0]

    model_info ={
        'model_ref': model_ref,
        'description':description, 
        'max_tokens': max_tokens, 
        'context': context, 
        'training_data': training_data, 
        'input_cost': input_cost, 
        'output_cost': output_cost,
        'Tier 1 TPM': TPM1,
        'Tier 1 RPM': RPM1,
        'Tier 1 RPD': RPD1,
        'Tier 2 TPM': TPM2,
        'Tier 2 RPM': RPM2,
        'Tier 2 RPD': RPD2}

    return DataFrame(model_info).set_index('model_ref')

