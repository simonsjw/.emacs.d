#!/usr/bin/env python

import logging
from logging.handlers import RotatingFileHandler
from logging import Logger
from logging import Formatter
from logging import LogRecord
import shutil
import gzip
import os
from pathlib import Path
from dotenv import load_dotenv
from datetime import datetime
from typing_extensions import override

# Explicitly load environment variables from .env in the project root. 
script_dir = Path(__file__).resolve().parent                                       # src directory
project_root = script_dir.parent                                                   # Project root
_ = load_dotenv(project_root / ".env")


class CustomFormatter(logging.Formatter):
    """Custom formatter to ensure timestamps are formatted with microseconds."""

    @override
    def formatTime(self, record: LogRecord, datefmt: str | None = None) -> str:
        """
        Override formatTime to correctly format timestamps with microseconds.
        """
        created_time = datetime.fromtimestamp(record.created)
        if datefmt:
            return created_time.strftime(datefmt)
        
        return created_time.strftime("%Y-%m-%d %H:%M:%S.%f")                      # Ensures full microseconds


def namer(name: str) -> str:
    """Function to rename a log file."""
    return name + ".gz"

def rotator(source: str | Path, dest: str | Path) -> None:
    """Function to rotate the log file."""
    with open(source, "rb") as f_in:
        with gzip.open(dest, "wb") as f_out:
            shutil.copyfileobj(f_in, f_out)
    os.remove(source)

def setup_logger(
    logger_name: str | None = None,
    log_file: str | None = None,
    log_file_maximum_size: int | None = None,
    backup_count: int | None = None,
    log_level: int | None = None,
) -> Logger:
    """
    Sets up the logging configuration to write logs to a specified file.

    Args:
        logger_name (str, optional):  Name of the logger. If None, root logger is used.
        log_file (str, optional):     Path to the log file. If None, defaults from
                                      environment or preset.
        log_file_maximum_size (int, optional):
                                      Maximum size of log before rotation (in bytes).
                                      Defaults to value from environment or 10MB.
        backup_count (int, optional): Number of backup log files to retain.
                                      Defaults to value from environment or 10.
        log_level (int, optional):    Logging level.
                                      Defaults to value from environment or
                                      logging.DEBUG.

    Returns:
        Logger:                       Configured logger instance.
    """
    # If log_file is not provided, construct it relative to the script's directory
    if not log_file:
        # Get the directory where this script resides
        script_dir = Path(__file__).resolve().parent
        # Define the log directory relative to the script directory
        log_dir = script_dir.parent / "logs"
        # Ensure the log directory exists
        log_dir.mkdir(parents=True, exist_ok=True)
        # Default log file path
        log_file = os.getenv("LOG_FILE_PATH", str(log_dir / "app.log"))

    if not log_file_maximum_size:
        log_file_maximum_size = int(os.getenv("LOG_MAX_SIZE", 10 * 1024 * 1024))    # 10 MB

    if not backup_count:
        backup_count = int(os.getenv("LOG_BACKUP_COUNT", 10))

    log_level_int: int
    if not log_level:
        log_level_str: str = os.getenv("LOG_LEVEL", "DEBUG").upper()
        log_level_int  = getattr(logging, log_level_str, logging.DEBUG)
    else:
        log_level_int = log_level

    # Create or get the logger
    logger: Logger = \
        logging.getLogger(logger_name) if logger_name else logging.getLogger()
    logger.setLevel(log_level_int)

    # Prevent adding multiple handlers to the same logger
    if not logger.handlers:
        
        # Create a RotatingFileHandler
        handler: RotatingFileHandler = RotatingFileHandler(
            filename=log_file,
            maxBytes=log_file_maximum_size,
            backupCount=backup_count
        )
        handler.rotator = rotator
        handler.namer = namer
        
        # Define the custom format
        log_format = "[%(asctime)s; %(levelname)s; %(funcName)s] %(message)s; %(name)s;"
        formatter: Formatter = CustomFormatter(
            fmt=log_format,
            datefmt="%Y-%m-%d %H:%M:%S.%f")

        handler.setFormatter(formatter)

        # Add the handler to the logger
        logger.addHandler(handler)

        logger.info("Logger initialised.")

    return logger

#  LocalWords:  RotatingFileHandler Args gz funcName
