#!/usr/bin/env python
# logging_setup.py

"""
Utility Module for File Paths, JSON Handling, and Random Character Operations

This module provides a variety of utility functions for handling file paths,
JSON operations, random character generation, and text processing.

Functions:
    __createClass(suffix=None, prefix="FilePath")
        Creates a class called "FilePath" with an optional module name based
        on the given file suffix.

    objectType(object)
        Extends the type function to determine file types based on suffix if
        the object is a file path.

    count_lines_in_file(file_path)
        Get the number of lines in a large text file.

    read_specific_line(file_path, line_number)
        Reads a specific line from a file without loading the entire file into memory.

    add_prefix_to_filename
        Add a prefix to a filepath.

    normalise_string(string_object, targetChar)
        Removes "_" and any characters provided, providing a Snake cased return.

    normalise_keys(data: Any)
        Normalise keys in a dictionary object found anywhere within a data object.
    
    int_to_en(int)
        Given an integer between 0 and 999,999,999,999,999, print it in English.

    get_next_available_filepath(filepath, digits=3)
        Generates the next available file path with a numeric suffix if the
        original file path already exists. The number of digits for the suffix
        can be adjusted using the `digits` parameter.

    choice_to_dict(choice)
        Converts a Choice object to a dictionary.

    read_text_file(file_path)
        Opens a text file and reads its content.

    save_object_to_file(obj, file_path)
        Saves any arbitrary Python object to a file by converting it to a
        string.

    save_as_json(objects, output_file)
        Saves a JSON object to disk.

    save_as_jsonl(objects, local_jsonl_source_file)
        Saves a list of JSON objects to disk as a JSONL file.

    read_jsonl(jsonl_file)
        Reads a JSONL file and returns a list of Python dictionaries.

    list_files_in_folder(folder_path)
        Lists all files in a given folder.

    remove_keys_from_dict(data_input, keys_to_remove)
        Recursively removes specified keys from a copy of a nested dictionary
        and returns it.

    generate_safe_characters()
        Returns a list of safe string characters for use in Python, such as
        for random file name generation.

    get_random_character_pair(character_pair_store, string_filter='')
        Randomly selects a file and a choice from a directory of character
        pair choices returned from GPT,
        and returns the character pair JSON, choice number, and file name.

    remove_tags(text)
        Removes a substring '[GEN_TAG*]' from a string, where * is a wildcard.

    updateString(template, job)
        Takes a string template and updates it with values determined b5y the
        job tuple,
        which contains a dictionary and an integer, string, or list of strings.
"""

import copy
import json
import os
import pathlib
import random
import re
import string
from pathlib import Path
from typing import Any, TypeGuard


def __createClass(suffix: str | None = None, prefix: str = "FilePath") -> type:
    """
    Creates a class called "FilePath" with an optional module name based
    on the given file suffix.

    Args:
        suffix (Optional[str]): The suffix to be used in the class module name.
        prefix (str): The prefix for the class name. Defaults to "FilePath".

    Returns:
        type: A new class based on the given prefix and optional suffix.

    Example:
        >>> MyFilePath = __createClass(suffix="txt", prefix="CustomPath")
        >>> isinstance(Path("example.txt"), MyFilePath)
        False  # This checks if 'example.txt' is an instance of CustomPath.
    """
    class_name = prefix

    # Create a new class
    new_class = type(class_name, (Path,), {})
    if suffix is not None:
        # Change the __module__ attribute to include the suffix
        new_class.__module__ = suffix

    return new_class


def objectType(object: Any) -> type | str:
    """
    Extends the type function to determine file types based on suffix if
    the object is a file path.

    Args:
        object (Any): The object whose type is to be determined.

    Returns:
        Union[type, str]: The type of the object or a custom string with the
        suffix if it's a file path.

    Example:
        >>> objectType(Path("example.txt"))
        <class '__main__.FilePath'>  # Example if FilePath was created.
        >>> objectType("some string")
        <class 'str'>
    """
    if (
        isinstance(object, str)
        or isinstance(object, pathlib.Path)
        or isinstance(object, pathlib.PurePath)
    ):
        if isinstance(object, pathlib.Path) or isinstance(object, pathlib.PurePath):
            object = str(object)
        if "." in object:
            suffix: str = object[-object[::-1].find(".") - 1 :].lower()
            return __createClass(suffix)
        else:
            return str(type(object))

    return type(object)


def count_lines_in_file(file_path: str | Path) -> int:
    """
    Get the number of lines in a large text file.
    """
    with open(file_path, "r") as file:
        # Using sum with generator expression for efficient line count
        return sum(1 for _ in file)


def read_specific_line(file_path: str | Path, line_number: int) -> str | None:
    """
    Reads a specific line from a file without loading the entire file into memory.

    Args:
    file_path (str): Path to the file.
    line_number (int): The line number to read (1-based index).

    Returns:
    str: The content of the specified line, or None if the line does not exist.
    """
    with open(file_path, "r") as file:
        for current_line_number, line in enumerate(file, start=1):
            if current_line_number == line_number:
                return (
                    line.strip()
                )  # Return the line content without newline characters
    return None  # If the line number is out of range


def add_prefix_to_filename(file_path: Path, prefix: str) -> Path:
    """
    Adds a specified prefix to the filename of a given Path object and returns a new
    Path object with the updated filename.

    Parameters:
    -----------
    file_path : Path
        The original Path object representing the full path to the file whose name
        needs to be prefixed.
    prefix : str
        The string to be added as a prefix to the filename.

    Returns:
    --------
    Path
        A new Path object with the same directory structure as `file_path` but with the
        filename prefixed by `prefix`.

    Example:
    --------
    >>> file_path = \
    Path("/your/home/path/OpenAI/GENERATED_CHARACTERS/batches/PROCESSED_FULL_CHARACTER_20230827.jsonl")
    >>> prefix = "REDO_"
    >>> new_path = add_prefix_to_filename(file_path, prefix)
    >>> print(new_path)
    /your/home/path/OpenAI/GENERATED_CHARACTERS/batches/REDO_PROCESSED_FULL_CHARACTER_20230827.jsonl

    Notes:
    ------
    This function does not modify the original file or its contents; it only creates a
    new Path object with the modified filename.
    """

    # Extract the filename and its parent directory
    filename = file_path.name
    parent_dir = file_path.parent

    # Add the prefix to the filename
    new_filename = f"{prefix}{filename}"

    # Return the new Path object with the updated filename
    return parent_dir / new_filename


def normalise_string(string_object: str, targetChar: str ="") -> str:
    """
    This function removes "_" and any characters provided in the string TARGETCHAR
    which are found in STRING_OBJECTS, capitalising the components to result in a Snake
    cased return.
    """
    targetChars: list[str] = list(targetChar)
    
    if not "_" in targetChar:
        targetChars.append("_")
    
    for char in targetChars:
        string_object = \
            "".join([i.title() for i in string_object.split(char)])
    
    return string_object


def normalise_keys(data: Any) -> Any:
    """
    Normalise keys in a dictionary object found anywhere within a data object.
    """
    if isinstance(data, dict):
        return {normalise_string(k, " .`"): normalise_keys(v) for k, v in data.items()}
    if isinstance(data, list):
        return [normalise_keys(item) for item in data]
    return data

    
def int_to_en(num: int) -> str:
    """
    Given an int32 number between 0 and 999,999,999,999,999, print it in English.
    """
    d: dict[int, str] = {
        0: "zero",
        1: "one",
        2: "two",
        3: "three",
        4: "four",
        5: "five",
        6: "six",
        7: "seven",
        8: "eight",
        9: "nine",
        10: "ten",
        11: "eleven",
        12: "twelve",
        13: "thirteen",
        14: "fourteen",
        15: "fifteen",
        16: "sixteen",
        17: "seventeen",
        18: "eighteen",
        19: "nineteen",
        20: "twenty",
        30: "thirty",
        40: "forty",
        50: "fifty",
        60: "sixty",
        70: "seventy",
        80: "eighty",
        90: "ninety",
    }

    k = 1000
    m = k * 1000
    b = m * 1000
    t = b * 1000

    assert 0 <= num

    if num < 20:
        return d[num]

    if num < 100:
        if num % 10 == 0:
            return d[num]
        else:
            return d[num // 10 * 10] + "-" + d[num % 10]

    if num < k:
        if num % 100 == 0:
            return d[num // 100] + " hundred"
        else:
            return d[num // 100] + " hundred and " + int_to_en(num % 100)

    if num < m:
        if num % k == 0:
            return int_to_en(num // k) + " thousand"
        else:
            return int_to_en(num // k) + " thousand, " + int_to_en(num % k)

    if num < b:
        if (num % m) == 0:
            return int_to_en(num // m) + " million"
        else:
            return int_to_en(num // m) + " million, " + int_to_en(num % m)

    if num < t:
        if (num % b) == 0:
            return int_to_en(num // b) + " billion"
        else:
            return int_to_en(num // b) + " billion, " + int_to_en(num % b)

    if num % t == 0:
        return int_to_en(num // t) + " trillion"
    else:
        return int_to_en(num // t) + " trillion, " + int_to_en(num % t)

    raise AssertionError("num is too large: %s" % str(num))


def get_next_available_filepath(
    filepath_object: Path | str, digits: int = 3
) -> Path | str:
    """
    Generate the next available file path with a numeric suffix if the original
    file path already exists.

    This function checks if a file already exists at the given file path. If it
    does, the function appends or increments a numeric suffix (e.g., `_001`,
    `_002`, etc.) before the file extension to create a new, unique file path.
    The number of digits for the suffix can be adjusted using the `digits`
    parameter.

    Args:
        filepath (Path or str): The original file path. This can be a `Path`
        object or a string.
        digits (int, optional): The number of digits to use for the numeric
        suffix. Defaults to 3.

    Returns:
        Path: Either a `Path` object or a string object corresponding to input that
              corresponds to the next available file path.

    Example:
        >>> from pathlib import Path
        >>> original_path = Path("output.txt")
        >>> new_path = get_next_available_filepath(original_path, digits=4)
        >>> print(new_path)
        # If 'output.txt' exists, this might print 'output_0001.txt'.
        # If 'output_0001.txt' also exists, it might print 'output_0002.txt',
        # and so on.
    """

    filepath: Path
    if isinstance(filepath_object, str):
        filepath = Path(filepath_object)
    else:
        filepath = filepath_object

    # Split the file into its name, suffix, and parent path
    parent: Path = filepath.parent
    stem: str = filepath.stem
    suffix: str = filepath.suffix

    # Regular expression to match files with the suffix pattern `name_00n.ext`
    pattern: re.Pattern[str] = re.compile(r"(.*?)(_\d+)?$")

    match: re.Match[str] | None = pattern.match(
        stem
    )  # Match can be None if no match occurs

    if match:
        base_name: str = match.group(1)
        number_string: str | None = match.group(2)

        if number_string:
            # Strip the leading underscore and convert to integer
            number: int = int(number_string[1:])
        else:
            number = 0

        # Increment the number until an available filename is found
        while filepath.exists():
            number += 1
            # Adjust the zero-padding according to the digits parameter
            new_suffix: str = f"_{str(number).zfill(digits)}"
            filepath = parent / f"{base_name}{new_suffix}{suffix}"

        if isinstance(filepath_object, str):
            return str(filepath)
        else:
            return filepath

    return filepath_object  # if you get to here no construction was required.


def calculate_percentile(number: int, numbers_list: list[int | float]) -> float:
    """
    Calculate the percentile rank of a given number within a list of numbers.

    The function sorts the list of numbers in ascending order, determines the rank
    of the specified number, and calculates its percentile rank based on its
    position in the sorted list.

    Parameters:
    number (float or int): The number for which the percentile is to be calculated.
    numbers_list (list of float or int): A list of numbers in which the percentile
                                         rank of the given number will be determined.

    Returns:
    float: The percentile rank of the given number within the list of numbers.

    Example:
    >>> numbers = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
    >>> calculate_percentile(50, numbers)
    44.44444444444444
    """
    # Sort the list of numbers
    sorted_list: list[int | float] = sorted(numbers_list)

    # Get the rank of the number in the sorted list
    rank: float = sorted_list.index(number) / (len(sorted_list) - 1)

    # Calculate the percentile
    percentile: float = rank * 100

    return percentile


def choice_to_dict(choice: dict[str, Any]) -> dict[str, Any]:
    """
    Converts a Choice object to a dictionary.

    Args:
        choice (Dict[str, Any]): The Choice object to convert.

    Returns:
        Dict[str, Any]: A dictionary representing the Choice object.

    Example:
        >>> choice = {"text": "example"}
        >>> result = choice_to_dict(choice)
        >>> print(result)
        {'text': 'example'}
    """
    return {
        "text": choice[
            "text"
        ],  # or choice.text, depending on how the object is structured
        # Include any other fields you need from the choice
    }


def read_text_file(file_path: Path | str) -> str:
    """
    Opens a text file and reads its content.

    Args:
        file_path (Path | str): The path to the text file.

    Returns:
        str: The content of the text file.

    Example:
        >>> content = read_text_file("example.txt")
        >>> print(content)
        "This is an example text."
    """
    with open(file_path, "r") as file:
        return file.read()


def save_object_to_file(
    obj: Any, file_path: Path | str, no_overwrite: bool = True, digits: int = 3
) -> Path | str:
    """
    Save any arbitrary Python object to a file by converting it to a string.

    This function converts the provided Python object to a string and saves it
    to the specified file path. The conversion method depends on the type of
    the object:

    - For dictionaries and lists, the object is converted to a JSON-formatted
      string.
    - For other objects, the object is converted using the `str()` function.

    Args:
        obj: The Python object to be saved. This can be any object such as a
             dictionary, list, string, or custom object.
        file_path (str or Path):
             The file path where the object will be saved.
        no_overwrite (bool):
             If true, the file will be saved with a version number in the case
             where a file of the same name already exists. (default=True)
        digits (int):
             The number of digits anticipated for the version number.
             (default=3)
             example -
                 if 3 then numbers can range from 001 to 999.
                 if 2 then numbers can range from 01 to 99.
    Example:
        >>> my_dict = {"key": "value", "list": [1, 2, 3]}
        >>> file_path = "output.txt"
        >>> save_object_to_file(my_dict, file_path)
        # This will save the dictionary in a JSON format to 'output.txt'
    """
    if no_overwrite:
        file_path = get_next_available_filepath(file_path, digits)

    # Convert the object to a string
    if isinstance(obj, (dict, list)):
        # Use json.dumps to ensure it's properly formatted
        obj_str = json.dumps(obj, indent=4)
    else:
        # Use str for other objects
        obj_str = str(obj)

    # Save the string to a file
    with open(file_path, "w") as file:
        _ = file.write(obj_str)

    return file_path


def save_as_json(
    objects: Any, output_file: Path | str, no_overwrite: bool = True, digits: int = 3
) -> None:
    """
    Saves a JSON object to disk.

    Args:
        objects (Any):
            The JSON object to save.
            output_file (Path | str): The path where the JSON file will
            be saved.
        no_overwrite (bool):
            If true, the file will be saved with a version number in the case
            where a file of the same name already exists. (default=True)
        digits (int):
            The number of digits anticipated for the version number.
            (default=3)
            example -
                if 3 then numbers can range from 001 to 999.
                if 2 then numbers can range from 01 to 99.
    Example:
        >>> data = {"key": "value"}
        >>> save_as_json(data, "output.json")
        # This will save the dictionary as a JSON file 'output.json'
    """
    if no_overwrite:
        output_file = get_next_available_filepath(output_file, digits)

    with open(output_file, "w") as file:
        json.dump(objects, file, indent=4)


def save_as_jsonl(
    objects: list[Any],
    local_jsonl_source_file: Path | str,
    no_overwrite: bool = True,
    digits: int = 3,
) -> None:
    """
    Saves a list of JSON objects to disk as a JSONL file.
    This is a file format used for large JSON data sets that can be parsed to a
    list.

    The advantage of jsonl over json comes from the fact that each JSON object
    in the list is represented on a single line regardless of size. This
    results in the capacity to import particular rows. from large files without
    needing to build a full JSON representation of the file first.

    Args:
        objects (List[Any]):
            The list of JSON objects to save.
        local_jsonl_source_file (Union[Path, str]):
            The path where the JSONL file will be saved.
        no_overwrite (bool):
            If true, the file will be saved with a version number in the case
            where a file of the same name already exists. (default=True)
        digits (int):
            The number of digits anticipated for the version number.
            (default=3)
            example -
                if 3 then numbers can range from 001 to 999.
                if 2 then numbers can range from 01 to 99.
    Example:
        >>> data = [{"key": "value1"}, {"key": "value2"}]
        >>> save_as_jsonl(data, "output.jsonl")
        # This will save the list of dictionaries as a JSONL file
        # 'output.jsonl'
    """
    if no_overwrite:
        local_jsonl_source_file = get_next_available_filepath(
            local_jsonl_source_file, digits
        )

    with open(local_jsonl_source_file, "w") as file:
        for obj in objects:
            _ = file.write(json.dumps(obj) + "\n")


def read_jsonl(
    jsonl_file: Path | str, lines_to_return: list[int] | None = None
) -> list[dict[str, Any]]:
    """
    Reads a JSONL file and returns a list of Python dictionaries.

    The advantage of JSONL over JSON comes from the fact that each JSON object
    in the list is represented on a single line regardless of size. This
    allows importing specific rows from large files without needing to build a
    full JSON representation of the file first.

    Args:
        jsonl_file (Union[Path, str]): The path to the JSONL file.
        lines_to_return (Optional[List[int]]): A list of line numbers to
        return.
        If not provided, the entire file is returned.

    Returns:
        List[Dict[str, Any]]: A list of dictionaries representing the JSON
        objects in the specified lines or the entire file if no specific lines
        are requested.

    Example:
        >>> data = read_jsonl("output.jsonl")
        >>> print(data)
        [{'key': 'value1'}, {'key': 'value2'}]

        >>> data = read_jsonl("output.jsonl", lines_to_return=[1, 3])
        >>> print(data)
        [{'key': 'value1'}, {'key': 'value3'}]
    """
    RESULTS_DATA: list[dict[str, Any]] = []

    with open(jsonl_file, "r") as file:
        for i, line in enumerate(file, start=1):
            if lines_to_return is None or i in lines_to_return:
                # Parsing the JSON string into a dict and appending to the list
                json_object = json.loads(line.strip())
                RESULTS_DATA.append(json_object)

    return RESULTS_DATA


def list_files_in_folder(folder_path: str | Path):
    """
    Lists all files in a given folder.

    Args:
        folder_path (Union[Path, str]): The path to the folder.

    Returns:
        List[Path | str]: A list of Path or string objects representing the files in the
        folder. Type will be conformed to the folder_path type.

    Example:
        >>> files = list_files_in_folder("/path/to/folder")
        >>> for file in files:
        >>>     print(file)
        Path('/path/to/folder/file1.txt')
        Path('/path/to/folder/file2.txt')
    """
    folder: Path
    if isinstance(folder_path, str):
        folder = Path(folder_path)
    else:
        folder = folder_path

    # List all files in the folder
    file_list: list[Path] = [file for file in folder.glob("*") if file.is_file()]

    if isinstance(folder_path, str):
        return [str(path) for path in file_list]

    return file_list


def remove_keys_from_dict(
    data_input: dict[str, Any] | list[Any] | str | int | float,
    keys_to_remove: list[str],
) -> dict[str, Any] | list[Any] | str | int | float:
    """
    Recursively removes specified keys from a copy of a nested dictionary
    and returns it.

    Args:
        data_input (Dict[str, Any] | List[Any]): The dictionary or list
        to remove keys from.
        keys_to_remove (List[str]): A list of keys to remove.

    Returns:
        Any: The dictionary or list with specified keys removed.

    Example:
        >>> data = {"a": 1, "b": {"c": 2, "d": 3}}
        >>> cleaned_data = remove_keys_from_dict(data, ["d"])
        >>> print(cleaned_data)
        {'a': 1, 'b': {'c': 2}}
    """
    data: (
        dict[str, dict[str, Any] | list[Any] | str | int | float]
        | list[Any]
        | str
        | int
        | float
    ) = copy.deepcopy(data_input)
    if isinstance(data, dict):
        return {
            key: remove_keys_from_dict(value, keys_to_remove)
            for key, value in data.items()
            if key not in keys_to_remove
        }
    elif isinstance(data, list):
        return [remove_keys_from_dict(item, keys_to_remove) for item in data]

    return data


def generate_safe_characters() -> list[str]:
    """
    Returns a list of safe string characters for use in Python, such as
    for random file name generation.

    Returns:
        List[str]: A list of safe characters.

    Example:
        >>> safe_chars = generate_safe_characters()
        >>> print(safe_chars)
        ['a', 'b', 'c', ..., '0', '1', '2', ..., '_', '-', '.', ...]
    """
    # Define the set of characters that are problematic in filenames
    problematic_characters = set("/\0")

    # Add any other characters that are typically avoided in filenames
    # This list can be expanded based on specific needs
    additional_problematic_characters = set(':*?"<>|\\')
    problematic_characters.update(additional_problematic_characters)

    # Generate the list of safe characters
    safe_characters = [
        char
        for char in (string.ascii_letters + string.digits + string.punctuation)
        if char not in problematic_characters
    ]

    return safe_characters


def get_random_character_pair(
    character_pair_store: str, string_filter: str = ""
) -> dict[str, Any]:
    """
    Randomly selects a file and a choice from a directory of character
    pair choices returned from GPT,
    and returns the character pair JSON, choice number, and file name.

    Args:
        character_pair_store (str): The directory containing character pair
        files.
        string_filter (str, optional): A string filter to apply when selecting
        files. Defaults to ''.

    Returns:
        Dict[str, Any]: A dictionary containing the selected character pair
        JSON, choice number, and file name.

    Example:
        >>> pair = get_random_character_pair("/path/to/character_store")
        >>> print(pair)
        {'character_pair_json': '{"content": "example"}', 'choice': 0,
        'file_name': 'character_outputs_001.json'}
    """
    # select the character pair file.
    random_character_file = random.choice(
        [
            f
            for f in os.listdir(character_pair_store)
            if f[:18] == "character_outputs_" and (string_filter in f)
        ]
    )

    # extract the choices and pick one at random.
    json_object = read_text_file(
        Path(character_pair_store).joinpath(random_character_file)
    )
    json_object = json.loads(json_object)["choices"]
    choice = random.randint(0, len(json_object) - 1)
    json_object = (
        json.dumps(json_object[choice]["message"]["content"], indent=4)
        .encode("utf-8")
        .decode("unicode_escape")
    )

    return {
        "character_pair_json": json_object,
        "choice": choice,
        "file_name": random_character_file,
    }


def remove_tags(text: str) -> str:
    """
    Removes a substring '[GEN_TAG*]' from a string, where * is a wildcard.
    This is useful for ensuring tagged lines in a document template are
    distinct without impacting the final output.

    Args:
        text (str): The input string from which tags should be removed.

    Returns:
        str: The string with tags removed.

    Example:
        >>> text = "Nationality: [GEN_TAG_NAT_A]"
        >>> clean_text = remove_tags(text)
        >>> print(clean_text)
        'Nationality: '
    """
    s = text.find("[GEN_TAG")
    e = text[s:].find("]")
    return text[:s] + text[s + e + 1 :]


def updateString(
    template: str,
    job: tuple[dict[str, float], int]
    | tuple[dict[str, int], int]
    | tuple[dict[str, str], str]
    | tuple[dict[int, tuple[int | float, int | float]],],
) -> list[str | list[str] | Any]:
    """
    updateString is a function to introduce variation in prompt generation over a batch.
    Takes a string provided in template_string and updates it with values determined by
    the arguments in job tuple, which contains a dictionary and an integer, string, or
    list of strings. Each of these update approaches employ various random selection
    techniques so that over a list of identical input prompts, differing output prompts
    are produced. 

    Args:
        template_string (str):
            The string template to update.
        job (tuple[dict[Any, Any], int | str | list[str]]):
            A tuple containing a dictionary and a value to determine how to update
            the template.

    Returns:
        tuple[str, Any]:
            A tuple containing the updated string and the value used for the update.

    Example code:
        >>> template = 'Color: {}'
        >>> job = ({"red": 0.25, "yellow": 0.5, "pink": 0.25}, 1)
        >>> updated_string, update = updateString(template, job)
        >>> print(updated_string)
        'Color: yellow'

    Examples of all four possible forms: 
         ({"red": 0.25, "yellow": 0.5, "pink": 0.25}, 2)
         ({"blue": 1, "violet": 4}, 3)
         ({"apple": 'fruit', "brown": 'colour', '':'unknown'}, ['car', 'brown'])
         ({6: (-1, 1)},)


    Detail
    ------
    Legal values for the variable `job' consist of a tuple containing a dictionary  
    followed by an integer, a string or a list of strings.
         
    There are four sets of functionality provided and the appropriate
    functionality is determined by looking at the datatype of the values
    provided in the dictionary.

        float:     if the values are floating point numbers, then the keys of
                   the dictionary are used for choices and the values are used
                   for weights.
                   the integer in the second element of the tuple is used to
                   determine how many choices to return. The choices are made
                   with replacement.
                   example:
                   ({"red": 0.25, "yellow": 0.5, "pink": 0.25}, 2) instructs
                   the function to pick 2 samples with replacement from a
                   selection of 3.
                   The probabilities are weighted such that you have twice as
                   much chance of picking a yellow as you do a red or pink.
                   The weighting is equivalent to a probability when the total
                   of the weights is 1.0.

        int:       if the values are integers, then the keys of the dictionary
                   are used for choices and the values are used as the number
                   of times that item should be present in the list to be
                   picked from. The integer in the second element of the tuple
                   is used to determine how many choices to return. The choices
                   are made with replacement.
                   example:
                   ({"blue": 1, "violet": 4}, 3) instructs the function to pick
                   3 samples without replacement from a selection
                   equivalent to:
                   ["violet", "blue", "violet", "violet", "violet"]
                   (sort order does not affect the result)
                   Since there is only one occurance of 'blue', this result is
                   not possible:
                   ["blue", "violet", "blue"]
                   Since there are 4 'instances of violet that can be chosen,
                   this result is possible:
                   ["violet", "violet", "blue"]

        string:    if the values are strings, then the keys of the dictionary
                   are used to match strings in a list and return the value of
                   that key. Any unmatched strings can be replaced with the
                   value set to a key ''.
                   example:
                   ({"apple": 'fruit', "brown": 'colour', '':'unknown'},
                    ['car', 'brown'])
                   returns:
                   ['unknown', 'colour']

        tuple:     The values mark the upper and lower bound of a range from
                   which floats are randomly picked. If the key is n, then n  \
                   random floats are produced. Note the comma after the  \
                   dictionary to ensure it's a tuple list.
                   example:
                   ({6: (-1, 1)},)
                   returns 6 floats randomly selected from a uniform
                   distribution between -1 and 1:
                   [-0.44275180777200185, -0.053485076828885925,
                    0.6292184740806561, -0.6788648275011433,
                    0.3489169834185546, -0.20003386296085135]
    """

    def is_valid_float_job_structure(
        job: Any,
    ) -> TypeGuard[tuple[dict[str, float], int]]:
        """
        Validates that the input job has the structure:
        tuple[dict[str, float], int].
        """
        # Check if job is a tuple with two elements
        if not isinstance(job, tuple) or len(job) != 2:
            return False

        # Check the first element: dict[str, float]
        if not isinstance(job[0], dict) or not all(
            isinstance(k, str) and isinstance(v, float) for k, v in job[0].items()
        ):
            return False

        # Check the second element: int
        if not isinstance(job[1], int):
            return False

        return True

    def is_valid_int_job_structure(job: Any) -> TypeGuard[tuple[dict[str, int], int]]:
        """
        Validates that the input job has the structure:
        tuple[dict[str, int], int].
        """
        # Check if job is a tuple with two elements
        if not isinstance(job, tuple) or len(job) != 2:
            return False

        # Check the first element: dict[str, int]
        if not isinstance(job[0], dict) or not all(
            isinstance(k, str) and isinstance(v, int) for k, v in job[0].items()
        ):
            return False

        # Check the second element: None.
        if not job[1]:
            return False

        return True

    def is_valid_str_job_structure(job: Any) -> TypeGuard[tuple[dict[str, str], str]]:
        """
        Validates that the input job has the structure:
        tuple[dict[str, str], list[str]].
        """
        # Check if job is a tuple with two elements
        if not isinstance(job, tuple) or len(job) != 2:
            return False

        # Check the first element: dict[str, str]
        if not isinstance(job[0], dict) or not all(
            isinstance(k, str) and isinstance(v, str) for k, v in job[0].items()
        ):
            return False

        # Check the second element is a list of strings.
        if not isinstance(job[1], list) or not all(isinstance(e, str) for e in job[1]):
            return False

        return True

    def is_valid_tuple_job_structure(
        job: Any,
    ) -> TypeGuard[tuple[dict[int, tuple[int | float, int | float]]]]:
        """
        Validates that the input job has the structure:
        tuple[dict[int, tuple[int|float, int|float], ].
        """
        # Check if job is a tuple with a single element
        if not isinstance(job, tuple) or len(job) != 1:
            return False

        # Check the element: dict[int, tuple]
        if not isinstance(job[0], dict) or not all(
            isinstance(k, int) and isinstance(v, tuple) for k, v in job[0].items()
        ):
            return False

        return True

    update: list[str | float | int]
    if is_valid_float_job_structure(job):
        # Expecting job like: ({"red":0.25, "blue":0.75}, 2)
        # c: dict[str, float], n: int
        c_float: dict[str, float] = job[0]
        n_float: int = job[1]
        update = random.choices(list(c_float.keys()), list(c_float.values()), k=n_float)

    elif is_valid_int_job_structure(job):
        # Expecting job like: ({"blue":1, "violet":4}, 3)
        # c: dict[str, int], n: int
        c_int: dict[str, int] = job[0]
        n_int: int = job[1]
        update = random.sample(list(c_int.keys()), k=n_int, counts=list(c_int.values()))

    elif is_valid_str_job_structure(job):
        # Expecting job like: ({"apple":"fruit","brown":"colour","": "unknown"}, ["car","brown"])
        # m: dict[str, str], i: str|list[str]
        string_indices: dict[str, str] = job[0]
        string_targets: str = job[1]
        update = [string_indices.get(s, string_indices[""]) for s in string_targets]

    elif is_valid_tuple_job_structure(job):
        # Expecting job like: ({6:(-1,1)},)
        # m: dict[int, tuple[float,float]]
        range_specification = job[0]
        # The second element of job may not be needed in this scenario.
        (low, high) = next(iter(range_specification.values()))
        count = next(iter(range_specification.keys()))
        update = [random.uniform(low, high) for _ in range(count)]

    else:
        # Scenario not recognized or incomplete
        update = []

    return [remove_tags(template.format(*update)), update]


#  LocalWords:  str Args bool TARGETCHAR
