import time
from openai import OpenAI

from openai import (
    RateLimitError,
    APIConnectionError,
    AuthenticationError,
    BadRequestError,
    ConflictError,
    InternalServerError,
    NotFoundError,
    PermissionDeniedError,
    UnprocessableEntityError
)
from typing import Any

# os.environ["OPENAI_API_KEY"] is used implicitly in OpenAI() to source a key
# needed to access the API endpoint.

client: OpenAI = OpenAI()  # Initialise GPT-4 API


def call_gpt_api(argument_dictionary: dict[str, Any], timeout: int = 60) -> None:
    """
    This function handles accessing the API for GPT with retry logic on rate
    limits.
    It incorporates a timeout for retries to handle rate limiting gracefully.
    """
    start_time = time.time()
    retry_delay = 1  # Initial delay between retries in seconds
    max_delay = 60  # Maximum delay to avoid long waits

    while time.time() - start_time < timeout:
        try:
            response = client.chat.completions.create(**argument_dictionary)
            return response

        except RateLimitError as e:
            # Rate limit exceeded, handle the wait and retry
            print("Rate limit exceeded, attempting to retry...")
            remaining_time = timeout - (time.time() - start_time)
            if remaining_time <= 0:
                print(f"Waiting for rate limit failed. OpenAI API request exceeded " +
                      "rate limit: {e}")
                break  # Exit if the timeout has been exceeded

            wait_time = min(
                retry_delay, remaining_time
            )  # Calculate wait time, don't exceed remaining time
            time.sleep(wait_time)
            retry_delay = min(
                retry_delay * 2, max_delay, remaining_time
            )  # Exponential backoff


        except APIConnectionError as e:
            # Handle connection error, e.g. check network or log
            print("OpenAI API request failed to connect. \n" +
                  "Check your network settings, proxy configuration, " +
                  "SSL certificates or firewall rules.\n" + f"error: {e}")
            pass
        except AuthenticationError as e:
            # Handle authentication error, e.g. check credentials or log
            print("OpenAI API request was not authorised: Your API key or token was " +
                  "invalid, expired, or revoked. \n" +
                  "Check your API key or token and make sure it is correct and " +
                  "active. " +
                  "You may need to generate a new one from your account dashboard.\n" +
                  f"error: {e}")
        except BadRequestError as e:
            # Handle invalid request error, e.g. validate parameters or log
            print("Request was malformed or missing some required parameters, " +
                  "such as a token or an input. \n" +
                  "The error message should advise you on the specific error made.\n" +
                  "Check the documentation for the specific API method you are " +
                  "calling and make sure you are sending valid and complete " +
                  "parameters. \nYou may also need to check the encoding, format, or " +
                  "size of your request data." + f"error: {e}")
            pass
        except ConflictError as e:
            print("The resource was updated by another request.\n" +
                  "Try to update the resource again and ensure no other requests are " +
                  "trying to update it..\n" + f"error: {e}")
            pass
        except InternalServerError as e:
            print("Issue at Open AI.\n" +
                  "Retry your request after a brief wait and contact Open AI if the" +
                  " issue persists.\n" + f"error: {e}")
            pass
        except NotFoundError as e:
            print("Requested resource does not exist.\n" +
                  "Ensure you are the correct resource identifier.\n" + f"error: {e}")
            pass
        except PermissionDeniedError as e:
            print("You don't have access to the requested resource. \n" +
                  "Ensure you are using the correct API key, organization ID, and " +
                  "resource ID.\n" + f"error: {e}")
            pass
        except UnprocessableEntityError as e:
            print("Unable to process the request despite the format being correct.\n" +
                  "Please try the request again.\n" + f"error: {e}")
            pass
        except Exception as e:
            # Handle unexpected errors
            print(f"An unexpected error occurred: {e}")

    print("Request failed after timeout.")
    return None


#  LocalWords:  backoff nYou
