characters
    contains definitions of characters to be used in message generation. 
    File name is of the form char_00.json where 00 is a numeric index. 


interface_output                            : contains assorted text files with output from the GPT gui including 
                                                the 'playground' and the standard prompt. This is data collected 
                                                at the test stage which is then processed to ancillary data. 
                                                Maintained as it may come in useful. 
                                                
scripts
    gptAPI.py                               : call_gpt_api          - function call_gpt_api used to call the gpt api
    helpers.py                              : choice_to_dict        - function to convert a choice object to a dictionary
                                              read_text_file        - function to read a textfile from disk
                                              save_as_json          - function to save a json object to disk                             
    modelInfo.py                            : open_ai_model_details - function to return a dataframe with OpenAI model details accurate as of 2023.11.21
    QPQ_message_generation.py               : getQPQMessages        - function to generate a prompt and then use call_gpt_api to get data
    
to_delete                                   : a folder containing files pending deletion.
    
TRAINFILE                                   
    positiveBias
        QPQ.json
    processed_api
        
    raw_api
    testing
        QPQ.json
alertQPQ_prompt-GenerateCharacters.txt      :
alertQPQ_prompt-GenerateMessages.txt        :
character_generator.ipynb                   :
document_Analysis.ipynb                     :
document_generator-generator.ipynb          :
lastConstructedMessagePrompt.txt            :
main.py                                     :
README.txt                                  : this file.
