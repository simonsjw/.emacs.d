#!/usr/bin/env python
import debugpy

debugpy.listen(5678)
debugpy.wait_for_client()

import copy
import importlib.util
import json
import os
import random
import sys
import argparse
from importlib.machinery import ModuleSpec
from pathlib import Path
from types import ModuleType
from typing import Any, Literal, TypedDict
from collections.abc import Generator


######################################################################################
############################### 0) set root directory. ###############################
######################################################################################

home_path: str = os.path.dirname(os.getcwd())

######################################################################################
############### 1) IMPORT PROJECT SPECIFIC FUNCTIONS FROM LOCAL FILES. ###############
######################################################################################

# Derive the home directory 'OpenAI' from the path to this notebook.
# taken from character_pair_generation.ipynb

##############################
#  Set up helper function.
##############################
# Example: Define the file path
helpers_file_path: Path = Path(home_path).joinpath("path", "to", "helpers.py")

# Example: Get the module spec
helper_spec: ModuleSpec | None = importlib.util.spec_from_file_location(
    name="helpers", location=helpers_file_path
)

if helper_spec is None:
    raise ImportError(f"Cannot find the module specification for {helpers_file_path}")

# Create the module
helpers: ModuleType = importlib.util.module_from_spec(spec=helper_spec)
sys.modules["helpers"] = helpers

# Execute the module
if helper_spec.loader is not None:
    helper_spec.loader.exec_module(module=helpers)
else:
    raise ImportError("Spec loader is None, cannot execute the module.")


#######################
# Create data objects #
#######################

######################################################################################
############ 2) DEFINE LOCAL FUNCTIONS NEEDED TO GENERATE TRAINING EMAILS ############
######################################################################################


#####################################################################################
############# 3) USE LOCAL FUNCTIONS NEEDED TO GENERATE TRAINING EMAILS #############
#####################################################################################

########
# docs #
########
directory_structure: list[str] = helpers.read_text_file(Path(home_path).joinpath("path", "to", "directory_structure.txt"))
function_library: list[str] = helpers.read_text_file(Path(home_path).joinpath("path", "to", "function_library.txt"))
        
def parse_arguments() -> argparse.Namespace:
    # Set up argparse to override defaults with CLI args

    parser: argparse.ArgumentParser = argparse.ArgumentParser(
        description=(
            "SCRIPT NAME\n\n"
            "**Description of the SCRIPT purpose.**"
            "Include details of any output data, including file paths. "
            "The prompts are saved to:\n"
            "    OpenAI/GENERATED_CHARACTER_PAIRS/batches/BATCH_EMAIL_CHAINS_suffix."
            "jsonl"
            "**Description of interaction with args.** The suffix is set by passing "
            " a --suffix argument and defaults to an empty "
            "string."

            "The function can be used both interactively and programmatically. "
            "If used programmatically, the main function should be called and has this "
            "signature:\n\n"
            "    def main(suffix: str, batch_start: int, batch_end: int) -> list[int]\n"
            "\nRecall that base zero indices mean the full population is [0: 9,999]."
        ),
        epilog=(
            "EXAMPLES:\n"
            + "  Run batch processing with default settings:\n"
            + "    python mymodule.py --input_file input.txt --output_dir ./output\n\n"
            + "  Run batch processing with specific batch start and end:\n"
            + "    python mymodule.py --suffix 'new' --input_file input.txt "
            + "--batch_start 0 "
            + "--batch_finish 200\n\n"
            + "\n".join(function_library)
            + "DIRECTORY STRUCTURE:\n"
            + "\n".join(directory_structure)
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    _ = parser.add_argument(
        "--suffix", type=Path, help="The suffix to distinguish with the file name. "
    )

    _ = parser.add_argument(
        "--batch_start",
        type=int,
        help="The starting index (base zero) for records to be used from the character"
        + " file.",
    )

    return parser.parse_args()


# Run the process to generate training data.
def main(args: argparse.Namespace | None = None) -> list[int]:
    """
    Main function that either accepts arguments directly (from a program)
    or uses argparse to parse from CLI.
    and returns the arguments (Namespace object).
    """
    if args is None:  # If no args are passed, assume CLI execution
        args = parse_arguments()

    """
    GENERATE_EMAILS is a script to generate training data for Quid Pro Quo alerts.
    """
    # ** RUN FUNCTION HERE WITH ANY PRE AND POST PROCESSING **

    return ['a', 'b', 'c']   #Any return object, eg list[str]


# Entry point for the case where this is run as a standalone CLI
# process rather than importing as a module. When run as a standalone,
# process the namespace defaults to '__main__'
if __name__ == "__main__":
    _ = main()

#  LocalWords:  programmatically args openai LLM EMBEDDINGS nFrancisca nHenry nRecall
#  LocalWords:  abcdefghijklmnopqrstuvwxyz openai ImportError FX ipynb QPQ nFinalOutput
#  LocalWords:  these are spellings to be ignored with ispell. 
