#!/usr/bin/env python
"""
REGULATORY_NEWS_SCRAPER is a script to capture updates from Regulatory websites listed
in `data/site_targets_scraping_YYYY_MM_DD_HH_mm.json'. It saves down valid web scrape
targets into files (one per website target) at data/pages__NAME__YYYY_MM_DD_HH_mm.json
Additional details can be obtained by doing:
    GENERATE_EMAIL_PROMPTS.py --help

ARGS:
    (None)

PATHS:
Logging is to:
    logs/app.log

Input files:
    data/site_targets_scraping_YYYY_MM_DD_HH_mm.json:
        dict[list, list] provides the name of the body (key) and its website (value)
Output files:
    data/pages__NAME__YYYY_MM_DD_HH_mm.json:
        dict[str, dict[str, list[str]]]
        Note that the first level is a single key with value NAME, the organisation.
        The second level has two keys['Allowed_urls','Disallowed_urls'] with values
        being lists of strings (an empty list is a valid list of strings).
"""
import json
import re
import xml.etree.ElementTree as ET
from datetime import datetime
from argparse import Namespace, ArgumentParser, RawDescriptionHelpFormatter

# Import the setup_logger function from logger_setup.py
from logging import Logger

from pathlib import Path
from urllib.error import HTTPError
from urllib.parse import urljoin
from urllib.request import urlopen
from urllib.robotparser import RobotFileParser

import requests
from bs4 import BeautifulSoup, ResultSet

from src.helpers import save_as_json
from src.logging_setup import setup_logger

# Setup logger using the imported setup_logger function
logger: Logger = setup_logger(logger_name="GENERATE_SCRAPE_CANDIDATES")
logger.info("Defining functionality.")

def get_latest_version(str_file_prefix: str,
                       parent_dir: str | Path) -> Path | None:
    """
    Given a file name prefix, this function assumes a suffix of the form
    YYYY_MM_DD_HH_mm which can be used to determine the date and time the file was
    created. Where there are multiple files with the same prefix, this function returns
    the file path to the last file created. If there is only one file, then that is
    returned. 
    """
    return max(
        Path(parent_dir).glob(str_file_prefix + '*'),
        key=lambda p: datetime.strptime(p.stem.split(str_file_prefix)[1], '%Y_%m_%d_%H_%M'),
        default=None
)

def init_robot_file_parser(robots_parser: RobotFileParser, base_url: str,
                           contact_email: str) -> str:
    """
    Given a website at BASE_URL string, FETCH_ROBOTS_TXT returns the text from
    robot.txt file at the root of the site.

    CONTACT_EMAIL is a string passed in the header of the crawler as contact for this
    activity.
    """
    
    robots_url = urljoin(base_url, "/robots.txt")
    headers = {"User-Agent": "RegulatoryNewsScraperTargets/1.0 (Contact: " + contact_email + ")"}

    try:
        robots_response = requests.get(robots_url, headers=headers, timeout=10)
        robots_response.raise_for_status()
        robots_txt = robots_response.text
        robots_parser.set_url(robots_url)
        robots_parser.parse(robots_txt.splitlines())
        
    except requests.RequestException as e:
        logger.error(f"Error fetching robots.txt: {e}")
        robots_txt = ""

    return robots_txt


def get_sitemap(base_url: str, robots_txt: str, sitemap_urls: list[str]) -> None:
    """
    Given a website BASE_URL, text from robots.txt from that site ROBOTS_TXT and a
    list of strings SITEMAP_URLS, this function will search for a sitemap or
    sitemaps either included in the robots.txt file or else at the default location and
    append that location/those locations to SITEMAP_URLS.
    """
    
    # Look for Sitemap directives in robots.txt
    for line in robots_txt.splitlines():
        if line.lower().startswith("sitemap:"):
            sitemap_urls.append(line.split(":", 1)[1].strip())

    # If no sitemaps found, try common location
    if not sitemap_urls:
        default_sitemap = urljoin(base_url, "/sitemap.xml")
        sitemap_urls.append(default_sitemap)
        logger.debug(f"No sitemaps in robots.txt, trying: {default_sitemap}")


def parse_sitemap(target: str, sitemap_url: str, all_urls: list[str]) -> None:
    """
    Given a SITEMAP_URL, this function extracts a list representing the full set of
    pages represented in the map and appends the list to ALL_URLS. 
    """
    namespace: dict[str, str] = {"sitemap":
                                 "http://www.sitemaps.org/schemas/sitemap/0.9"}
    
    # Fetch the sitemap
    try: 
        response = urlopen(sitemap_url)
    except HTTPError as e:
        logger.warning(f"On {target}, we attempted to access sitemap: {sitemap_url}")
        logger.warning(f"{target} does not allow access: {e}")
        
        # exit this parse routine if we can't get the allowed pages to scrape. 
        return
    
    # Parse the sitemap    
    try: 
        root = ET.fromstring(response.read())
    except ET.ParseError as e:
        logger.warning(f"xml.etree.ElementTree failed to parse the sitemap from {target} at {sitemap_url}.")

        # exit this parse routine if we can't parse our sitemap to get pages to scrape. 
        return       
    
    # Check if it's a sitemap index by examining the root tag
    if root.tag == "{http://www.sitemaps.org/schemas/sitemap/0.9}sitemapindex":
        logger.info(f"Found sitemap index at {sitemap_url}")
        # Find all <loc> elements under <sitemap>
        sitemap_locs = \
            root.findall(".//sitemap:sitemap/sitemap:loc", namespace)
        for loc in sitemap_locs:
            nested_sitemap_url: str | None  = loc.text
            if nested_sitemap_url:
                logger.info(f"Processing nested sitemap: {nested_sitemap_url}")
            
                # Recursively process
                parse_sitemap(target, nested_sitemap_url, all_urls)
            else:
                 logger.debug(f"Nested sitemap evaluated as None for text: {nested_sitemap_url}")               
            
    elif root.tag == "{http://www.sitemaps.org/schemas/sitemap/0.9}urlset":
        logger.info(f"Found regular sitemap at {sitemap_url}")
        # Find all <loc> elements under <url>
        url_locs = \
            root.findall(".//sitemap:url/sitemap:loc", namespace)
        for loc in url_locs:
            url_loc_text = loc.text
            if url_loc_text: 
                all_urls.append(url_loc_text)
            else:
                logger.debug(f"url location evaluated to None: {loc}")
        logger.info(f"Added {len(url_locs)} URLs from {sitemap_url}")
    else:
        logger.debug(f"Unknown sitemap type: {root.tag}")


def get_sitemap_from_sitemap_page(base_url: str, sitemap_url: str, allowed_urls: list[str]) -> None:
    response = requests.get(sitemap_url)
    response.raise_for_status()  # Check for errors

    # Parse the HTML
    soup: BeautifulSoup = BeautifulSoup(response.text, "html.parser")

    # Find all <a> tags with href attributes
    links: ResultSet = soup.find_all("a", href=True)

    # Extract and clean URLs
    # base_url = "https://asic.gov.au"
    page_urls: set[str] = set()                                                         # Use a set to avoid duplicates
    
    for link in links:
        href = link["href"]
        # Filter for internal ASIC links (starting with "/" or full domain)
        if href.startswith("/"):
            full_url = base_url + href
            page_urls.add(full_url)
        elif href.startswith(base_url):
            page_urls.add(href)

    # Output the list
    for sitemap_url in sorted(page_urls):
        allowed_urls.append(sitemap_url)



## CONSOLE HELP SETUP. 
directory_structure: list[str] = helpers.read_text_file(
    Path(home_path).joinpath("OpenAI", "docs", "directory_structure.txt")
)
function_library: list[str] = helpers.read_text_file(
    Path(home_path).joinpath("OpenAI", "docs", "function_library.txt")
)


def parse_arguments() -> Namespace:
    # Set up argparse to override defaults with CLI args

    parser: ArgumentParser = ArgumentParser(
        description=(
            "GENERATE EMAIL PROMPTS\n\n"
            "This script produces a batch of prompts to be used in generating training"
            " data for Quid Pro Quo detection. The prompts are saved to:\n"
            "    OpenAI/GENERATED_CHARACTER_PAIRS/batches/BATCH_EMAIL_CHAINS_suffix."
            "jsonl"
            "The suffix is set by passing a --suffix (-s) argument and defaults to an "
            "empty string."
            "You can select the range of characters used by specifying --batch_start "
            "and --batch_finish (-b). If there are 10,000 pairs, the indices run from 0"
            " to 9,999.\n"
            "Alternatively, passing only a batch_start or batch_end without the other "
            "corresponding variable causes that number of pairs to be randomly "
            "selected.\n"
            "If neither batch_start or batch_end are selected, 2000 random pairs are "
            "used. If there are less than 2000 pairs provided, then all of those are \n"
            "used. The function can be used both interactively and programmatically. "
            "If used programmatically, the main function should be called and has this "
            "signature:\n\n"
            "    def main(suffix: str, batch_start: int, batch_end: int) -> list[int]\n"
            "\nRecall that base zero indices mean the full population for 10,000 "
            "elements is [0: 9,999]."
        ),
        epilog=(
            "EXAMPLES:\n"
            + "  Run batch processing with default settings: \n"
            + "    GENERATE_EMAIL_PROMPTS \n"
            + "  Run batch processing with specific batch start and end: \n"
            + "    GENERATE_EMAIL_PROMPTS "
            + "--batch_start 0 --batch_finish 200 \n\n"
            + "  Run batch processing with specific batch start and end. \n"
            + "  Add a suffix to the output file to make it unique. \n"
            + "    GENERATE_EMAIL_PROMPTS "
            + "-a 0 -b 200 --suffix 'test'  \n\n"
            + "".join(function_library)
            + "\n"
            + "This script is included with a set of directories "
            + "structured as below:\n"
            + "".join(directory_structure)
            + "\n\n"
        ),
        formatter_class=RawDescriptionHelpFormatter,
    )

    _ = parser.add_argument(
        "-s",
        "--suffix",
        type=str,
        help="The suffix to distinguish with the file name. "
    )

    _ = parser.add_argument(
        "-a",
        "--batch_start",
        type=int,
        help="The starting index (base zero) for records to be used from the character"
        + " file.",
    )

    _ = parser.add_argument(
        "-b",
        "--batch_finish",
        type=int,
        help="The end index (base zero) for records to be used from the character "
        + "file.",
    )

    return parser.parse_args()


        
## Main function
#  The function executed when this script is called from the command line.
def main(args: Namespace | None = None) -> list[int | str | None]:
    """
    Main function runs without accepting arguments or returning values.
    """

    logger.info("Starting main function.")

    if args is None:                                                                      # If no args are passed, assume CLI execution
        args = parse_arguments()
        logger.debug(f"Parsed arguments from CLI: {args}")
    else:
        logger.debug(f"Received arguments: {args}")

    # Log initial variables
    logger.debug(f"Suffix: {args.suffix}")
    logger.debug(f"Batch start: {args.batch_start}")
    logger.debug(f"Batch finish: {args.batch_finish}")

    
    logger.info("Running Main function.")

    ### Data
    logger.info("Collecting data.")

    contact_email: str = "simon.watson.sjw@gmail.com"

    all_urls: list[str] | list[None] = []
    sitemap_urls: list[str] | list[None] = []
    allowed_urls: list[str] | list[None] = []
    disallowed_urls: list[str] | list[None] = []
    
    pathProjectRoot: Path = Path(__file__).resolve().parent
    pathDataDirectory: Path = pathProjectRoot.joinpath('data')

    current_time: datetime = datetime.now()
    time_string: str = current_time.strftime("%Y_%m_%d_%H_%M")

    # get the latest list of scraping targets. 
    web_targets_path: Path | None = \
        get_latest_version('site_targets_scraping_', pathDataDirectory)

    # Open the scraping target JSON file and load its content
    if web_targets_path:
        with open(web_targets_path, 'r') as file:
            web_targets: dict[str, str] = json.load(file)
    else:
        logger.info("get_latest_version did not return a file of web targets. ")
        raise FileNotFoundError

    target_elements: dict[str, list[str]] = {'CBA':['newsroom.html']}

    # get the latest list of sitemap web pages to use in preference to anything else. 
    site_map_pages_override_path: Path | None = \
        get_latest_version('sitemap_page_override__', pathDataDirectory)

    # Open the scraping target JSON file and load its content
    if site_map_pages_override_path:
        with open(site_map_pages_override_path, 'r') as file:
            site_map_pages: dict[str, str] = json.load(file)
    else:
        logger.info("get_latest_version did not return a file of sitemap overrides. ")
        raise FileNotFoundError

    # for each web_target, collect a list of allowed and disallowed pages. 
    for target, base_url in list(web_targets.items()):
        
        # Step 1: initialise variables. 
        all_urls = []
        sitemap_urls = []
        allowed_urls = []
        disallowed_urls = []

        # assume there is a robots.txt unless we resort to using the sitemap web page.
        # The only case where we don't find it but continue is where we are able to get
        # pages from the site map which is set up as a web page.

        # We only get to that if there is no robots.txt file. This means no restriction
        # has been set on scraping. Setting this avoids us trying to use allowed_urls
        # when no robots.txt file is present (this would cause an error). 
        found_robots_txt_file = True   

        # Create RobotFileParser instance.
        rp: RobotFileParser = RobotFileParser()

        # Initialise the RobotFileParser instance and get the text from robots.txt
        robots_txt: str = init_robot_file_parser(rp, base_url, contact_email)

        # Step 2: Using robots.txt if possible, get the sitemap or sitemaps. 
        # (sitemap_urls is updated). 
        get_sitemap(base_url, robots_txt, sitemap_urls)
    
        # Step 3: Process sitemap(s) captured.
        for sitemap_url in sitemap_urls:
            parse_sitemap(target, sitemap_url, all_urls)

        # If we don't have any urls from this target site map, at this point there is
        # no point doing the rest of the routine so we exit early. 
        if not all_urls:
            logger.warning(f"No URLs found for {target}; sitemap(s) unavailable or empty.")
            if target in site_map_pages:
                logger.info(f"{target} site as a sitemap page. If there is no Robots.txt, we will scrape directly.")
                sitemap_page_url: str =  site_map_pages[target]
                get_sitemap_from_sitemap_page(base_url, sitemap_page_url, allowed_urls)
                found_robots_txt_file = False
                if not allowed_urls:
                    logger.warning(f"No pages were recovered from the {target} sitemap page at {sitemap_page_url}.")
                    continue       # this means we have not managed to get any urls from the sitemap page. 
            else: 
                continue
        
        # Step 5: If we have established the site has a robots.txt file, apply it to
        # the sitemap to determine the pages we are allowed to scrape.
        if found_robots_txt_file:
            for url in all_urls:
                if rp.can_fetch("*", url):
                    allowed_urls.append(url)
                else:
                    disallowed_urls.append(url)

        # Step 6: save down the recovered data. 
        scrapes: dict[str, dict[str, list[str]]] = \
            {target:{'Allowed_urls': allowed_urls, 'Disallowed_urls': disallowed_urls}}

        clean_target_string =  re.sub(r'[^a-z0-9\s]', '', target.lower())
        page_file_name: str = 'pages__' + clean_target_string + '__' + time_string + '.json'
        path_page_file: Path = pathDataDirectory.joinpath(page_file_name)
        save_as_json(scrapes, path_page_file)

        # Step 7: log results
        output_text: str = (f"\nTarget: {target}\nAllowed URLs:\n" \
                            + "\n".join(allowed_urls[:5]))
        if len(allowed_urls) > 5:
            output_text += f"\n...and {len(allowed_urls) - 5} more"

        if output_text: 
            logger.info(output_text)

        output_text = f"\nDisallowed URLs:\n".join(disallowed_urls[:5])
        if len(disallowed_urls) > 7:
            output_text += f"\n...and {len(disallowed_urls) - 5} more"

        if output_text: 
            logger.info(output_text)
        
        logger.info(f"Summary: {len(allowed_urls)} allowed, {len(disallowed_urls)} disallowed")


## Entry point
if __name__ == "__main__":
    _ = main()
    
        
#  LocalWords:  html sitemapindex urlset newsScraper CBA nTarget nAllowed nSummary CFTC
#  LocalWords:  RegulatoryNewsScraper simon nDisallowed ASIC
#  LocalWords:  RegulatoryNewsScraperTargets
