from typing import TypedDict, TypeAlias


# BATCH OUTPUT
# ------------
# The BATCH OUTPUT returned from OPENAI is a list of JSON objects. When converted to
# a list of python dictionaries, the object is structured as OPEN_AI_BATCH_OUTPUT.

# A type alias is used since this is a list of elements and without it, the interpreter
# would consider it to be a list of variables. 

class OPEN_AI_MESSAGE(TypedDict):
    role: str
    content: str
    refusal: str | None


class OPEN_AI_CHOICE(TypedDict):   
    index: int
    message: OPEN_AI_MESSAGE
    logprobs: int | None
    finish_reason: str


class OPEN_AI_USAGE(TypedDict):
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
    completion_tokens_details: dict[str, int]                                             # "reasoning_tokens", "accepted_prediction_tokens", "rejected_prediction_tokens"


class OPEN_AI_BODY(TypedDict):
    id: str
    object: str
    created: int
    model: str
    choices: list[OPEN_AI_CHOICE]
    usage: OPEN_AI_USAGE
    system_fingerprint: str


class OPEN_AI_RESPONSE(TypedDict):
    status_code: int
    request_id: str
    body: OPEN_AI_BODY


class OPEN_AI_PROMPT_OUTPUT(TypedDict):
    id: str
    custom_id: str
    response: OPEN_AI_RESPONSE
    error: str | None


# Define a type alias for OPEN_AI_BATCH_OUTPUT
OPEN_AI_BATCH_OUTPUT: TypeAlias = list[OPEN_AI_PROMPT_OUTPUT]



# MISCONDUCT_COMPONENTS
# ---------------------
# MISCONDUCT_COMPONENTS is a data object used to describe components of misconduct in
# Quid Pro Quo. 

LikelihoodType: TypeAlias = float

# Type for the SUMMARY key, allowing nested summaries
class SummaryType(TypedDict):
    summary: list[
        list[
            list[str] | str  # Supports nested lists of strings or plain strings
        ]
    ]

# Type for Character A and B actions
class CharacterType(TypedDict):
    actions: list[list[str | None]]  # List of lists containing strings or None

# Type for KEY STRATEGIES
class KeyStrategiesType(TypedDict):
    strategies: list[str]

# Type for a single Quid Pro Quo step
class MISCONDUCT_Step(TypedDict):
    LIKELIHOOD: LikelihoodType
    SUMMARY: list[str | SummaryType]  # A string or a complex nested summary
    CharacterA: list[list[str | None]]
    CharacterB: list[list[str | None]]
    KEY_STRATEGIES: list[str]

# Main container for all Quid Pro Quo Misconduct type components
class MISCONDUCT_Type(TypedDict):
    InitialSteps: MISCONDUCT_Step
    Execution: MISCONDUCT_Step
    PreviousQuidProQuo: MISCONDUCT_Step
    ThirdPartyQuidProQuo: MISCONDUCT_Step

# Top-level MISCONDUCT_COMPONENTS dictionary
class MISCONDUCT_COMPONENTS_OBJ(TypedDict):
    QPQ: MISCONDUCT_Type


    
# MISCONDUCT_STRATEGIES
# ---------------------
# MISCONDUCT_STRATEGIES is a data object used to describe strategies employed by people
# engaged in Quid Pro Quo misconduct. These strategies are grouped to facilitate a
# broader understanding of the behaviour. 

# Type for the DETAIL key
DetailType: TypeAlias = str

# Type for the DETECTION key
class DetectionType(TypedDict):
    detection: list[str]

# Type for the NO_STRATEGIES, INTERMEDIATE_STRATEGIES, and ADVANCED_STRATEGIES keys
class StrategyLevelsType(TypedDict):
    NO_STRATEGIES: list[str]
    INTERMEDIATE_STRATEGIES: list[str | list[str]]
    ADVANCED_STRATEGIES: list[str | list[str]]

# Type for each strategy's details
class StrategyDetailsType(TypedDict):
    DETAIL: DetailType
    LIKELIHOOD: LikelihoodType
    DETECTION: list[str]
    NO_STRATEGIES: list[str]
    INTERMEDIATE_STRATEGIES: list[str | list[str]]
    ADVANCED_STRATEGIES: list[str | list[str]]

# Main container for all Quid Pro Quo strategies
class QPQStrategiesType(TypedDict):
    IndirectLanguage: StrategyDetailsType
    SequentialEmails: StrategyDetailsType
    ThirdPartyCommunications: StrategyDetailsType
    PersonalChannels: StrategyDetailsType
    FavourBank: StrategyDetailsType
    BusinessAsUsual: StrategyDetailsType
    Negotiation: StrategyDetailsType
    LayeringRequests: StrategyDetailsType
    Distraction: StrategyDetailsType
    ParallelProjects: StrategyDetailsType

# Top-level MISCONDUCT_STRATEGIES dictionary
class MISCONDUCT_STRATEGIES_OBJ(TypedDict):
    QPQ: QPQStrategiesType
