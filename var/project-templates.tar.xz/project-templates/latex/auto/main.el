;; -*- lexical-binding: t; -*-

(TeX-add-style-hook
 "main"
 (lambda ()
   (TeX-add-to-alist 'LaTeX-provided-class-options
                     '(("article" "")))
   (TeX-add-to-alist 'LaTeX-provided-package-options
                     '(("babel" "english") ("geometry" "a4paper" "top=2cm" "bottom=2cm" "left=3cm" "right=3cm" "marginparwidth=1.75cm") ("amssymb" "") ("amsfonts" "") ("amstext" "") ("amsmath" "") ("physics" "") ("graphicx" "") ("subfig" "") ("caption" "") ("float" "") ("hyperref" "colorlinks=true" "allcolors=blue") ("csquotes" "") ("biblatex" "backend=biber" "style=numeric" "sorting=none")))
   (add-to-list 'LaTeX-verbatim-macros-with-braces-local "href")
   (add-to-list 'LaTeX-verbatim-macros-with-braces-local "hyperimage")
   (add-to-list 'LaTeX-verbatim-macros-with-braces-local "hyperbaseurl")
   (add-to-list 'LaTeX-verbatim-macros-with-braces-local "nolinkurl")
   (add-to-list 'LaTeX-verbatim-macros-with-braces-local "url")
   (add-to-list 'LaTeX-verbatim-macros-with-braces-local "path")
   (add-to-list 'LaTeX-verbatim-macros-with-delims-local "path")
   (TeX-run-style-hooks
    "latex2e"
    "article"
    "art10"
    "babel"
    "geometry"
    "amssymb"
    "amsfonts"
    "amstext"
    "amsmath"
    "physics"
    "graphicx"
    "subfig"
    "caption"
    "float"
    "hyperref"
    "csquotes"
    "biblatex")
   (LaTeX-add-labels
    "dynamics"
    "fig:pendulumViz")
   (LaTeX-add-bibliographies
    "ref"))
 :latex)

