#!/bin/bash

# my_script_template.sh - A template for Bash scripts in this project

# Exit on error
set -e

# Load environment variables
if [ -f .env ]; then
    source .env
else
    echo "Error: .env file not found"
    exit 1
fi

# Default variables
LOG_LEVEL=${LOG_LEVEL:-"INFO"}
SCRIPT_NAME=$(basename "$0")

# Usage function
usage() {
    echo "Usage: $SCRIPT_NAME [options]"
    echo "Options:"
    echo "  -h, --help    Display this help message"
    exit 1
}

# Parse arguments
while [[ $# -gt 0 ]]; do
    case "$1" in
        -h|--help)
            usage
            ;;
        *)
            echo "Unknown option: $1"
            usage
            ;;
    esac
    shift
done

# Logging function
log() {
    local level="$1"
    local message="$2"
    if [ "$LOG_LEVEL" = "DEBUG" ] || [ "$level" != "DEBUG" ]; then
        echo "[$level] $message"
    fi
}

# Main function
main() {
    log "INFO" "Starting $SCRIPT_NAME"
    log "DEBUG" "Project name: $PROJECT_NAME"
    log "INFO" "Script directory: $SCRIPT_DIR"

    # Add your script logic here
    echo "Hello, this is a template script!"

    log "INFO" "Completed $SCRIPT_NAME"
}

# Run main
main